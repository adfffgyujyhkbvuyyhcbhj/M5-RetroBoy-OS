// ============================================================================
//  FLAP BIRD - M5 (A) = battre des ailes ; HAUT (PWR) = pause
// ============================================================================
#include "common.h"

namespace flap {

static const uint32_t STEP_US = 20000;          // 50 Hz
static const float GRAV = 0.20f, FLAP_V = -3.0f, MAX_FALL = 4.2f;
static const int   BIRD_X = 56, BALL_R = 6;
static const int   PIPE_W = 26, GAP_H = 46, PIPE_SPACING = 108;
static const int   GROUND_Y = 120;
static const float SPEED = 1.7f;

enum State { TITLE, PLAY, PAUSED, OVER };
static State state = TITLE;
static float by = 60, vy = 0;
static int   score = 0, best = 0, overTicks = 0, animT = 0;
static float groundX = 0;
struct Pipe { float x; int gapY; bool scored; };
static Pipe pipes[4]; static int nPipes = 0;
struct Cloud { float x; int y; };
static Cloud clouds[4];
static Preferences pr;
static uint32_t last = 0, acc = 0;

static void addPipe(float x) {
  if (nPipes >= 4) return;
  pipes[nPipes++] = {x, (int)rnd(14 + GAP_H / 2, GROUND_Y - 14 - GAP_H / 2), false};
}
static void reset() {
  by = 60; vy = 0; score = 0; nPipes = 0; animT = 0; overTicks = 0;
  addPipe(SCR_W + 40); addPipe(SCR_W + 40 + PIPE_SPACING);
}
void begin() {
  pr.begin("flap", false); best = pr.getInt("best", 0);
  state = TITLE; reset(); by = 60; groundX = 0; last = 0; acc = 0;
  for (int i = 0; i < 4; i++) clouds[i] = {(float)(i * 70 + rnd(0, 30)), (int)rnd(8, 60)};
}

static void die() {
  state = OVER; overTicks = 0;
  if (score > best) { best = score; pr.putInt("best", best); }
  sfx(300, 90); sfx(150, 220, false);
}
static void doFlap() { vy = FLAP_V; sfx(880, 30); sfx(1180, 40, false); }

static void step() {
  animT++;
  groundX -= SPEED; if (groundX <= -16) groundX += 16;
  for (int i = 0; i < 4; i++) { clouds[i].x -= 0.35f; if (clouds[i].x < -40) { clouds[i].x = SCR_W + rnd(0, 30); clouds[i].y = rnd(8, 60); } }
  if (state == TITLE) { by = 62 + sinf(animT * 0.12f) * 5; return; }
  if (state == OVER) { if (overTicks < 200) overTicks++; if (by < GROUND_Y - BALL_R) { vy += GRAV; if (vy > MAX_FALL) vy = MAX_FALL; by += vy; if (by > GROUND_Y - BALL_R) by = GROUND_Y - BALL_R; } return; }
  // PLAY
  vy += GRAV; if (vy > MAX_FALL) vy = MAX_FALL;
  by += vy;
  for (int i = 0; i < nPipes; i++) pipes[i].x -= SPEED;
  if (nPipes > 0 && pipes[0].x + PIPE_W < 0) { memmove(&pipes[0], &pipes[1], sizeof(Pipe) * (nPipes - 1)); nPipes--; }
  if (nPipes > 0 && pipes[nPipes - 1].x < SCR_W - PIPE_SPACING + 4) addPipe(pipes[nPipes - 1].x + PIPE_SPACING);
  for (int i = 0; i < nPipes; i++) {
    Pipe &p = pipes[i];
    if (!p.scored && p.x + PIPE_W < BIRD_X - BALL_R) { p.scored = true; score++; sfx(1318, 40); sfx(1760, 60, false); }
    if (BIRD_X + BALL_R - 1 > p.x && BIRD_X - BALL_R + 1 < p.x + PIPE_W) {
      if (by - BALL_R + 2 < p.gapY - GAP_H / 2 || by + BALL_R - 2 > p.gapY + GAP_H / 2) { die(); return; }
    }
  }
  if (by + BALL_R >= GROUND_Y) { by = GROUND_Y - BALL_R; die(); return; }
  if (by - BALL_R < 0) { by = BALL_R; if (vy < 0) vy = 0; }
}

static void drawPipe(int x, int top, int bottom) {   // tuyau vert qui va de top a bottom (y ecran)
  uint16_t g1 = rgb(90, 190, 40), g2 = rgb(60, 140, 30), g3 = rgb(150, 235, 90), dk = rgb(30, 70, 20);
  if (bottom <= top) return;
  canvas.fillRect(x, top, PIPE_W, bottom - top, g1);
  canvas.fillRect(x + 3, top, 4, bottom - top, g3);
  canvas.fillRect(x + PIPE_W - 6, top, 5, bottom - top, g2);
  canvas.drawRect(x, top, PIPE_W, bottom - top, dk);
}
static void drawBird(int cx, int cy, float v) {
  uint16_t body = rgb(250, 210, 50), dk = rgb(120, 70, 10);
  int tilt = v > 2 ? 1 : (v < -1 ? -1 : 0);
  canvas.fillCircle(cx, cy, BALL_R + 1, dk);
  canvas.fillCircle(cx, cy, BALL_R, body);
  canvas.fillCircle(cx + 3, cy - 2 + tilt, 3, TFT_WHITE); canvas.fillCircle(cx + 4, cy - 2 + tilt, 1, TFT_BLACK);
  canvas.fillTriangle(cx + 5, cy + tilt, cx + 12, cy + 2 + tilt, cx + 5, cy + 4 + tilt, rgb(240, 110, 30));
  int wy = ((animT / 5) & 1) ? 1 : -2;
  if (state == PLAY || state == TITLE) canvas.fillEllipse(cx - 3, cy + 2 + wy, 4, 2, rgb(230, 160, 30));
  else canvas.fillEllipse(cx - 3, cy + 2, 4, 2, rgb(230, 160, 30));
}

static void render() {
  canvas.fillScreen(rgb(110, 200, 235));
  canvas.fillRect(0, 80, SCR_W, 40, rgb(150, 220, 240));
  for (int i = 0; i < 4; i++) { int cx = (int)clouds[i].x, cy = clouds[i].y; canvas.fillRoundRect(cx, cy, 34, 9, 4, TFT_WHITE); canvas.fillCircle(cx + 12, cy, 6, TFT_WHITE); canvas.fillCircle(cx + 22, cy + 1, 5, TFT_WHITE); }
  // ville au loin
  for (int i = 0; i < 16; i++) { int h = 14 + ((i * 37) % 22); canvas.fillRect(i * 16 - ((int)(-groundX) % 16) / 1 * 0, GROUND_Y - h, 14, h, rgb(120, 190, 215)); }
  for (int i = 0; i < nPipes; i++) {
    Pipe &p = pipes[i]; int x = (int)p.x;
    int topEnd = p.gapY - GAP_H / 2, botStart = p.gapY + GAP_H / 2;
    drawPipe(x + 2, 0, topEnd - 8); drawPipe(x, topEnd - 8, topEnd);
    drawPipe(x + 2, botStart + 8, GROUND_Y); drawPipe(x, botStart, botStart + 8);
  }
  canvas.fillRect(0, GROUND_Y, SCR_W, SCR_H - GROUND_Y, rgb(222, 200, 130));
  canvas.fillRect(0, GROUND_Y, SCR_W, 4, rgb(100, 200, 50));
  for (int x = (int)groundX; x < SCR_W; x += 16) canvas.fillTriangle(x, GROUND_Y + 4, x + 8, GROUND_Y + 4, x + 4, GROUND_Y + 10, rgb(190, 165, 95));
  drawBird(BIRD_X, (int)by, vy);
  if (state == PLAY || state == PAUSED) { char b[8]; snprintf(b, sizeof b, "%d", score); txtO(b, SCR_W / 2, 6, &fonts::Font4, TFT_WHITE, rgb(60, 60, 60), textdatum_t::top_center); }
  if (state == TITLE) {
    txtO("FLAP BIRD", SCR_W / 2, 14, &fonts::Font4, rgb(255, 230, 60), rgb(110, 60, 0), textdatum_t::top_center);
    if (best > 0) { char b[24]; snprintf(b, sizeof b, L("best %d","record %d"), best); txtO(b, SCR_W / 2, 108, &fonts::Font2, TFT_WHITE, rgb(60, 60, 60), textdatum_t::top_center); }
  }
  if (state == PAUSED) txtO("PAUSE", SCR_W / 2, 52, &fonts::Font4, TFT_WHITE, rgb(60, 60, 60), textdatum_t::top_center);
  if (state == OVER) {
    canvas.fillRoundRect(50, 26, 140, 72, 6, rgb(250, 240, 200)); canvas.drawRoundRect(50, 26, 140, 72, 6, rgb(110, 60, 0));
    txt("GAME OVER", SCR_W / 2, 31, &fonts::Font4, rgb(200, 50, 30), textdatum_t::top_center);
    char b[32]; snprintf(b, sizeof b, L("score %d   best %d","score %d   record %d"), score, best);
    txt(b, SCR_W / 2, 62, &fonts::Font2, rgb(80, 50, 10), textdatum_t::top_center);
  }
}

void loop() {
  uint32_t now = micros();
  if (last == 0) last = now;
  acc += now - last; last = now; if (acc > 100000) acc = 100000;
  bool a = M5.BtnA.wasPressed(), p = M5.BtnPWR.wasPressed();
  switch (state) {
    case TITLE: if (a) { reset(); state = PLAY; doFlap(); } break;
    case PLAY: if (p) { state = PAUSED; sfx(440, 50); } else if (a) doFlap(); break;
    case PAUSED: if (p || a) { state = PLAY; sfx(660, 50); } break;
    case OVER: if (a && overTicks >= 40) { reset(); state = PLAY; doFlap(); } break;
  }
  while (acc >= STEP_US) { if (state != PAUSED) step(); acc -= STEP_US; }
  render();
  canvas.pushSprite(0, 0);
}

void icon(int x, int y) {
  canvas.fillRoundRect(x, y, 64, 64, 6, rgb(110, 200, 235));
  canvas.fillRect(x, y + 52, 64, 12, rgb(222, 200, 130)); canvas.fillRect(x, y + 52, 64, 3, rgb(100, 200, 50));
  canvas.fillRect(x + 40, y, 16, 20, rgb(90, 190, 40)); canvas.fillRect(x + 38, y + 18, 20, 6, rgb(60, 140, 30));
  canvas.fillRect(x + 40, y + 38, 16, 14, rgb(90, 190, 40)); canvas.fillRect(x + 38, y + 34, 20, 6, rgb(60, 140, 30));
  canvas.drawRect(x + 40, y, 16, 20, rgb(30, 70, 20)); canvas.drawRect(x + 38, y + 34, 20, 6, rgb(30, 70, 20));
  int cx = x + 22, cy = y + 30;
  canvas.fillCircle(cx, cy, 11, rgb(120, 70, 10)); canvas.fillCircle(cx, cy, 10, rgb(250, 210, 50));
  canvas.fillCircle(cx + 5, cy - 3, 4, TFT_WHITE); canvas.fillCircle(cx + 6, cy - 3, 2, TFT_BLACK);
  canvas.fillTriangle(cx + 8, cy, cx + 18, cy + 3, cx + 8, cy + 6, rgb(240, 110, 30));
  canvas.fillEllipse(cx - 5, cy + 3, 6, 3, rgb(230, 160, 30));
}

}  // namespace flap
