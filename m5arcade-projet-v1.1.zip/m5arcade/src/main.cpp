// ============================================================================
//  AD ARCADE - M5StickC Plus2
//  Menu facon console + jeux. Menu : B (cote) = suivant, HAUT (PWR) = precedent, M5 (A) = lancer
//  Dans un jeu : maintenir HAUT (PWR) 1,5 s = retour au menu
// ============================================================================
#include "common.h"

M5Canvas canvas(&M5.Display);

int  g_bright = 2;
bool g_sound = true;
int  g_sleepIdx = 1;
int  g_lang = 0;                              // 0 = English, 1 = Francais
bool g_quit = false;
static const int BRI[5] = {30, 70, 120, 180, 255};
static const uint32_t SLEEP_MS[5] = {30000, 60000, 120000, 300000, 0};
static Preferences mp;

void applyBrightness() { M5.Display.setBrightness(BRI[g_bright]); }
void saveSettings() { mp.putInt("bri", g_bright); mp.putBool("snd", g_sound); mp.putInt("slp", g_sleepIdx); mp.putInt("lang", g_lang); }
void sfx(int freq, int ms, bool stopPrev) { if (g_sound) M5.Speaker.tone(freq, ms, -1, stopPrev); }

struct GameDef { const char* en; const char* fr; void (*begin)(); void (*loop)(); void (*icon)(int, int); };
static const GameDef GAMES[] = {
  {"CHROME DINO",    "CHROME DINO",    dino::begin,     dino::loop,     dino::icon},
  {"FLAP BIRD",      "FLAP BIRD",      flap::begin,     flap::loop,     flap::icon},
  {"METEORS",        "METEORES",       space::begin,    space::loop,    space::icon},
  {"MAZE",           "LABYRINTHE",     maze::begin,     maze::loop,     maze::icon},
  {"BREAKOUT",       "CASSE-BRIQUES",  breakout::begin, breakout::loop, breakout::icon},
  {"INVADERS",       "INVADERS",       invaders::begin, invaders::loop, invaders::icon},
  {"SLALOM",         "SLALOM",         ski::begin,      ski::loop,      ski::icon},
  {"STACK",          "STACK",          stack::begin,    stack::loop,    stack::icon},
  {"RACING",         "COURSE",         race::begin,     race::loop,     race::icon},
  {"FLIGHT",         "AVION",          sky::begin,      sky::loop,      sky::icon},
  {"RIVER",          "RIVIERE",        river::begin,    river::loop,    river::icon},
  {"FISH",           "POISSON",        fish::begin,     fish::loop,     fish::icon},
  {"MUSIC",          "MUSIQUE",        music::begin,    music::loop,    music::icon},
  {"SETTINGS",       "REGLAGES",       settings::begin, settings::loop, settings::icon},
};
static const int NGAMES = sizeof(GAMES) / sizeof(GAMES[0]);
static int sel = 0, running = -1;
static float slide = 0;                       // animation de defilement (en tuiles)
static uint32_t lastAct = 0;                  // dernier appui (pour l'ecran de veille)
static int saver = 0;                         // 0 = normal, 1 = veille (animation), 2 = ecran eteint
static int batLevel = 100; static bool batChg = false; static uint32_t batT = 0;

// ----------------------------------------------------------------------------- menu
static void dim(int x, int y) { for (int j = 0; j < 64; j += 2) canvas.drawFastHLine(x, y + j, 64, rgb(10, 10, 18)); }

static void drawBattery(int x, int y, int lvl, bool chg) {            // petite pile facon telephone + pourcentage
  uint16_t col = lvl <= 15 ? rgb(235, 60, 60) : (lvl <= 35 ? rgb(250, 190, 40) : rgb(90, 220, 110));
  canvas.drawRoundRect(x, y, 22, 11, 3, rgb(220, 224, 240)); canvas.fillRect(x + 22, y + 3, 2, 5, rgb(220, 224, 240));
  int w = (lvl * 18) / 100; if (w < 1 && lvl > 0) w = 1;
  canvas.fillRoundRect(x + 2, y + 2, w, 7, 2, col);
  if (chg) { canvas.fillTriangle(x + 12, y + 1, x + 7, y + 6, x + 11, y + 6, rgb(255, 255, 255)); canvas.fillTriangle(x + 10, y + 5, x + 14, y + 5, x + 9, y + 10, rgb(255, 255, 255)); }
  char b[8]; snprintf(b, sizeof b, "%d%%", lvl); txt(b, x + 28, y + 1, &fonts::Font0, rgb(220, 224, 240));
}

static uint16_t rainbow(int h) {
  h &= 255; int r, g, b;
  if (h < 85) { r = 255 - h * 3; g = h * 3; b = 0; } else if (h < 170) { h -= 85; r = 0; g = 255 - h * 3; b = h * 3; } else { h -= 170; r = h * 3; g = 0; b = 255 - h * 3; }
  return rgb(r, g, b);
}
struct Star { float x, y, v; };
static Star stars[40]; static bool starsInit = false;
static void initStars() { for (auto &s : stars) s = {(float)rnd(0, SCR_W), (float)rnd(0, SCR_H), 0.15f + (float)rnd(0, 100) / 120.0f}; starsInit = true; }

static void drawBackdrop() {                                   // degrade + etoiles qui defilent + grille en perspective
  for (int y = 0; y < SCR_H; y += 3) canvas.fillRect(0, y, SCR_W, 3, mixc(rgb(14, 12, 40), rgb(70, 34, 96), y * 256 / SCR_H));
  if (!starsInit) initStars();
  for (auto &s : stars) {
    s.x -= s.v; if (s.x < 0) { s.x += SCR_W; s.y = rnd(0, SCR_H); }
    uint16_t c = s.v > 0.8f ? rgb(255, 255, 255) : (s.v > 0.45f ? rgb(190, 190, 230) : rgb(110, 110, 160));
    canvas.drawPixel((int)s.x, (int)s.y, c); if (s.v > 0.8f) canvas.drawPixel((int)s.x + 1, (int)s.y, c);
  }
  uint32_t t = millis();
  for (int i = 0; i < 6; i++) { int y = 88 + (int)(powf((float)((i * 16 + (t / 60) % 16)) / 96.0f, 2.0f) * 46); canvas.drawFastHLine(0, y, SCR_W, rgb(70, 40, 120)); }
  for (int i = -6; i <= 6; i++) canvas.drawLine(SCR_W / 2 + i * 8, 88, SCR_W / 2 + i * 34, 135, rgb(60, 34, 104));
}

static void drawMenu() {
  drawBackdrop();
  canvas.fillRect(0, 0, SCR_W, 19, rgb(12, 10, 30)); canvas.drawFastHLine(0, 19, SCR_W, rainbow((int)(millis() / 12)));
  drawBattery(5, 4, batLevel, batChg);
  txt("AD ARCADE", SCR_W / 2 + 7, 3, &fonts::Font2, rgb(60, 20, 10), textdatum_t::top_center);
  txt("AD ARCADE", SCR_W / 2 + 6, 2, &fonts::Font2, rgb(255, 210, 80), textdatum_t::top_center);
  char b[10]; snprintf(b, sizeof b, "%d/%d", sel + 1, NGAMES); txt(b, SCR_W - 5, 6, &fonts::Font0, rgb(150, 160, 200), textdatum_t::top_right);
  float pulse = (sinf(millis() * 0.008f) + 1) * 0.5f;
  for (int d = -1; d <= 1; d++) {
    int idx = (sel + d + NGAMES) % NGAMES;
    float px = SCR_W / 2 - 32 + (d - slide) * 82;
    int ix = (int)px, iy = 25 + (d == 0 ? (int)(sinf(millis() * 0.006f) * 2) : 6);
    if (ix > SCR_W || ix < -64) continue;
    canvas.fillEllipse(ix + 32, 92, 28, 3, rgb(8, 6, 20));                                  // ombre au sol
    if (d == 0 && slide == 0) {
      uint16_t g1 = mixc(rgb(70, 40, 110), rgb(255, 210, 80), 90 + (int)(pulse * 110)); canvas.fillRoundRect(ix - 7, iy - 7, 78, 78, 12, g1);
    }
    if (d == 0) canvas.fillRoundRect(ix - 4, iy - 4, 72, 72, 9, rgb(255, 210, 80));
    GAMES[idx].icon(ix, iy);
    if (d != 0) dim(ix, iy);
  }
  canvas.fillRect(0, 103, SCR_W, 32, rgb(12, 10, 30)); canvas.drawFastHLine(0, 103, SCR_W, rgb(255, 210, 80));
  const char* nm = L(GAMES[sel].en, GAMES[sel].fr);
  txt(nm, SCR_W / 2 + 1, 109, &fonts::Font4, rgb(90, 30, 20), textdatum_t::top_center); txt(nm, SCR_W / 2, 108, &fonts::Font4, TFT_WHITE, textdatum_t::top_center);
  canvas.fillTriangle(5, 58, 13, 50, 13, 66, rgb(255, 210, 80)); canvas.fillTriangle(SCR_W - 5, 58, SCR_W - 13, 50, SCR_W - 13, 66, rgb(255, 210, 80));
}

// ----------------------------------------------------------------------------- ecran de veille
static float svx = 60, svy = 30, svdx = 0.9f, svdy = 0.7f; static int svGame = 0;
static void drawSaver() {
  canvas.fillScreen(0);
  for (int i = 0; i < 20; i++) { int sx = (i * 61 + 7) % SCR_W, sy = (i * 37 + 11) % SCR_H; if (((millis() / 400) + i) % 5) canvas.drawPixel(sx, sy, rgb(70, 74, 100)); }
  svx += svdx; svy += svdy; bool hit = false;
  if (svx < 0) { svx = 0; svdx = -svdx; hit = true; } if (svx > SCR_W - 64) { svx = SCR_W - 64; svdx = -svdx; hit = true; }
  if (svy < 0) { svy = 0; svdy = -svdy; hit = true; } if (svy > SCR_H - 64) { svy = SCR_H - 64; svdy = -svdy; hit = true; }
  if (hit) svGame = (svGame + 1) % NGAMES;
  GAMES[svGame].icon((int)svx, (int)svy);
  canvas.pushSprite(0, 0);
}

static void toMenu() {
  running = -1; slide = 0; g_quit = false; lastAct = millis(); saver = 0;
  M5.Speaker.stop(); applyBrightness();
}

// ----------------------------------------------------------------------------- intro facon demo scene des annees 90
static void intro() {
  const char* SCROLL = "     WELCOME TO AD ARCADE ***  14 GAMES IN YOUR POCKET ***  TILT  PRESS  PLAY ***  ENJOY !!!     ";
  const int SL = strlen(SCROLL);
  const char* SUB = "WELCOME  -  M5STICKC PLUS2 EDITION";
  static const int ARP[16] = {220, 262, 330, 440, 330, 262, 220, 262, 196, 247, 294, 392, 294, 247, 196, 247};
  if (!starsInit) initStars();
  float sx = SCR_W; int t = 0;
  M5.update();
  while (true) {
    M5.update();
    if (t > 15 && (M5.BtnA.wasPressed() || M5.BtnB.wasPressed() || M5.BtnPWR.wasPressed())) break;
    sx -= 5.0f; if (sx + SL * 12 < 0) break;
    canvas.fillScreen(rgb(4, 2, 16));
    for (int y = 0; y < SCR_H; y += 3) canvas.fillRect(0, y, SCR_W, 3, mixc(rgb(4, 2, 16), rgb(30, 12, 52), y * 256 / SCR_H));
    for (int k = 0; k < 3; k++) {                                              // barres "copper"
      int cy = 56 + (int)(sinf(t * 0.055f + k * 1.9f) * 38);
      uint16_t base = k == 0 ? rgb(255, 90, 40) : (k == 1 ? rgb(40, 200, 255) : rgb(230, 60, 255));
      for (int d = -8; d <= 8; d++) { int lvl = (9 - abs(d)) * 28; uint16_t c = mixc(rgb(8, 2, 20), base, lvl > 256 ? 256 : lvl); if (d == 0) c = mixc(base, TFT_WHITE, 120); canvas.drawFastHLine(0, cy + d, SCR_W, c); }
    }
    for (auto &st : stars) { st.x -= st.v * 2.5f; if (st.x < 0) { st.x += SCR_W; st.y = rnd(0, SCR_H); } canvas.drawPixel((int)st.x, (int)st.y, st.v > 0.8f ? TFT_WHITE : rgb(150, 150, 210)); }
    // logo : lettres qui tombent puis ondulent
    const char* LOGO = "AD ARCADE";
    for (int i = 0; i < 9; i++) {
      int tt = t - i * 4; if (tt < 0) continue;
      int y = 30 + (tt < 18 ? -((18 - tt) * (18 - tt)) / 3 : 0) + (int)(sinf(t * 0.14f + i * 0.7f) * 7);
      int x = 12 + i * 24; char ch[2] = {LOGO[i], 0}; if (ch[0] == ' ') continue;
      txt(ch, x + 3, y + 3, &fonts::Font0, rgb(10, 4, 30), textdatum_t::top_left, 4.0f);
      txt(ch, x + 1, y + 1, &fonts::Font0, TFT_WHITE, textdatum_t::top_left, 4.0f);
      txt(ch, x, y, &fonts::Font0, rainbow(i * 26 + t * 5), textdatum_t::top_left, 4.0f);
    }
    int n = (t - 50) / 2; if (n > (int)strlen(SUB)) n = strlen(SUB);
    if (n > 0) { char sb[40]; memcpy(sb, SUB, n); sb[n] = 0; txt(sb, SCR_W / 2, 78, &fonts::Font0, (t / 4) & 1 ? rgb(255, 230, 120) : TFT_WHITE, textdatum_t::top_center, 1.0f); }
    canvas.fillRect(0, 98, SCR_W, 37, rgb(0, 0, 0)); canvas.drawFastHLine(0, 98, SCR_W, rainbow(t * 4)); canvas.drawFastHLine(0, 99, SCR_W, rainbow(t * 4 + 60)); canvas.drawFastHLine(0, 134, SCR_W, rainbow(t * 4 + 120));
    for (int i = 0; i < SL; i++) {
      int x = (int)sx + i * 12; if (x < -12 || x > SCR_W) continue;
      char ch[2] = {SCROLL[i], 0}; if (ch[0] == ' ') continue;
      int y = 109 + (int)(sinf(t * 0.2f + i * 0.5f) * 7);
      txt(ch, x + 1, y + 1, &fonts::Font0, rgb(40, 20, 60), textdatum_t::top_left, 2.0f);
      txt(ch, x, y, &fonts::Font0, rainbow(i * 14 + t * 6), textdatum_t::top_left, 2.0f);
    }
    canvas.pushSprite(0, 0);
    if (t % 4 == 0) sfx(ARP[(t / 4) & 15] * ((t / 64) & 1 ? 2 : 1), 90);
    if (t % 16 == 0) sfx(ARP[(t / 16) & 3] / 2, 120, false);
    t++; delay(24);
  }
  M5.Speaker.stop();
  for (int f = 0; f < 12; f++) {                                              // fondu en damier
    for (int by = 0; by < 9; by++) for (int bx = 0; bx < 15; bx++) if (((bx * 7 + by * 3) % 13) < f + 1) canvas.fillRect(bx * 16, by * 16, 16, 16, rgb(12, 10, 30));
    canvas.pushSprite(0, 0); delay(25);
  }
  sfx(660, 70); sfx(880, 70, false); sfx(1320, 140, false);
}

void setup() {
  auto cfg = M5.config();
  M5.begin(cfg);
  pinMode(4, OUTPUT); digitalWrite(4, HIGH);   // maintien de l'alimentation (StickC Plus2)
  M5.Display.setRotation(SCR_ROT);
  mp.begin("arcade", false);
  sel = mp.getInt("sel", 0); if (sel < 0 || sel >= NGAMES) sel = 0;
  g_bright = mp.getInt("bri", 2); if (g_bright < 0 || g_bright > 4) g_bright = 2;
  g_sound = mp.getBool("snd", true);
  g_lang = mp.getInt("lang", 0) ? 1 : 0;
  g_sleepIdx = mp.getInt("slp", 1); if (g_sleepIdx < 0 || g_sleepIdx > 4) g_sleepIdx = 1;
  applyBrightness();
  M5.Speaker.setVolume(140);
  canvas.setColorDepth(16);
  canvas.createSprite(SCR_W, SCR_H);
  tilt::load();
  intro();
  if (tilt::valid()) tilt::zero();             // stabilisation unique : la position tenue au demarrage = "a plat" pour tous les jeux
  else tilt::startCalibration();               // premier demarrage : assistant d'inclinaison
  lastAct = millis();
}

void loop() {
  M5.update();
  bool anyBtn = M5.BtnA.wasPressed() || M5.BtnB.wasPressed() || M5.BtnPWR.wasPressed();
  if (tilt::calibrating()) { tilt::calibrationStep(); lastAct = millis(); return; }
  if (running >= 0) {
    if (M5.BtnPWR.pressedFor(1500) || g_quit) { sfx(440, 60); sfx(330, 90, false); toMenu(); return; }
    GAMES[running].loop();
    return;
  }
  uint32_t now = millis();
  // ----- ecran de veille (uniquement dans le menu)
  if (saver) {
    if (anyBtn) { saver = 0; applyBrightness(); lastAct = now; return; }          // le 1er appui reveille seulement
    if (saver == 1) { drawSaver(); delay(16); if (now - lastAct > SLEEP_MS[g_sleepIdx] + 60000) { saver = 2; M5.Display.setBrightness(0); } }
    else delay(40);
    return;
  }
  if (anyBtn) lastAct = now;
  if (SLEEP_MS[g_sleepIdx] && now - lastAct > SLEEP_MS[g_sleepIdx]) { saver = 1; M5.Display.setBrightness(BRI[g_bright] > 40 ? 40 : BRI[g_bright]); return; }
  if (now - batT > 3000 || batT == 0) {
    batT = now; int l = M5.Power.getBatteryLevel(); if (l >= 0) batLevel = l > 100 ? 100 : l;
    batChg = M5.Power.isCharging() == m5::Power_Class::is_charging;
  }
  if (M5.BtnB.wasPressed()) { sel = (sel + 1) % NGAMES; slide = -1; sfx(1200, 20); }
  if (M5.BtnPWR.wasPressed()) { sel = (sel + NGAMES - 1) % NGAMES; slide = 1; sfx(1000, 20); }
  if (slide != 0) { slide *= 0.7f; if (fabsf(slide) < 0.03f) slide = 0; }
  if (M5.BtnA.wasPressed()) {
    mp.putInt("sel", sel); sfx(880, 50); sfx(1320, 90, false);
    g_quit = false; GAMES[sel].begin(); running = sel;
    return;
  }
  drawMenu();
  canvas.pushSprite(0, 0);
}
