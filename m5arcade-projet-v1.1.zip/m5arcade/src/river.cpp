// ============================================================================
//  RIVIERE - descends la riviere en kayak : penche le M5 pour pagayer a droite / a gauche.
//  Evite les rochers et les troncs, ramasse les pieces. HAUT = pause.
// ============================================================================
#include "common.h"

namespace river {

static const uint32_t STEP_US = 20000;
static const int SEGH = 3, NSEG = 48, BY = 100;
enum State { TITLE, PLAY, PAUSED, OVER };
static State state = TITLE;
static Preferences pr;
static uint32_t last = 0, acc = 0;

struct Seg { float cx, w; uint8_t dl, dr, ol, orr; };         // decor gauche / droite : type + decalage
static Seg seg[NSEG];
static float curDir = 0, curW = 104, tgtW = 104;
struct Obj { float x, y, a, b; uint8_t type; bool on; };       // 0 rocher (a = rayon), 1 tronc (a = demi-longueur, b = angle), 2 piece
static Obj objs[14];
struct Pop { float x, y; int t; char s[10]; uint16_t col; }; static Pop pops[3];
struct Splash { float x, y; int t; }; static Splash spl[10];

static float bx = 120, bv = 0, spd = 1.8f, dist = 0, off = 0, spawnAcc = 0;
static int lives = 3, invul = 0, endT = 0, animT = 0, steps = 0, shake = 0;
static uint32_t score = 0, best = 0, bonus = 0;

static void pop(float x, float y, const char* s, uint16_t col) { for (auto &p : pops) if (p.t <= 0) { p.x = x; p.y = y; p.t = 36; p.col = col; strncpy(p.s, s, 9); p.s[9] = 0; return; } }
static void splash(float x, float y) { for (auto &s : spl) if (s.t <= 0) { s = {x, y, 14}; return; } }

static float cxPrev = 120;
static void makeSeg(Seg &s) {
  curDir += ((int)rnd(0, 100) - 50) * 0.0035f - (cxPrev - 120) * 0.0012f;
  curDir = clampf(curDir, -0.9f, 0.9f);
  cxPrev += curDir * 1.6f;
  float lim = curW / 2 + 22;
  cxPrev = clampf(cxPrev, lim, SCR_W - lim);
  curW += (tgtW - curW) * 0.02f;
  s.cx = cxPrev; s.w = curW;
  s.dl = rnd(0, 100) < 14 ? (uint8_t)rnd(1, 4) : 0; s.dr = rnd(0, 100) < 14 ? (uint8_t)rnd(1, 4) : 0;
  s.ol = rnd(6, 26); s.orr = rnd(6, 26);
}
static void reset() {
  bx = 120; bv = 0; spd = 1.8f; dist = 0; off = 0; spawnAcc = 0; lives = 3; invul = 0; endT = 0; steps = 0; score = 0; bonus = 0; shake = 0;
  curDir = 0; curW = tgtW = 104; cxPrev = 120;
  for (auto &s : seg) makeSeg(s);
  for (auto &o : objs) o.on = false;
  for (auto &p : pops) p.t = 0;
  for (auto &s : spl) s.t = 0;
}
void begin() {
  pr.begin("river", false); best = pr.getInt("best", 0);
  tilt::load();
  reset(); state = TITLE; last = 0; acc = 0;
}
static void gameOver() {
  state = OVER; endT = 0;
  if (score > best) { best = score; pr.putInt("best", best); }
  sfx(260, 120); sfx(110, 320, false);
}

// bords de la riviere a la hauteur y (ecran)
static void edges(float y, float &l, float &r, float &c) {
  float f = (y + SEGH - off) / SEGH; int i = (int)f; if (i < 0) i = 0; if (i > NSEG - 2) i = NSEG - 2; float t = f - i; if (t < 0) t = 0; if (t > 1) t = 1;
  c = seg[i].cx + (seg[i + 1].cx - seg[i].cx) * t; float w = seg[i].w + (seg[i + 1].w - seg[i].w) * t;
  l = c - w / 2; r = c + w / 2;
}

static void spawnObj() {
  float l, r, c; edges(-14, l, r, c);
  int k = rnd(0, 99);
  if (k < 58) {
    int n = rnd(0, 99) < 35 ? 2 : 1; float x0 = 0;
    for (int i = 0; i < n; i++) for (auto &o : objs) if (!o.on) {
      float rad = rnd(6, 10), x;
      for (int tries = 0; tries < 6; tries++) { x = rnd((int)(l + rad + 8), (int)(r - rad - 8)); if (i == 0 || fabsf(x - x0) > 40) break; }
      o = {x, -16.f, rad, 0, 0, true}; x0 = x; break;
    }
  } else if (k < 78) {
    for (auto &o : objs) if (!o.on) { o = {(float)rnd((int)(l + 30), (int)(r - 30)), -20.f, (float)rnd(13, 18), ((int)rnd(0, 60) - 30) * 0.0175f, 1, true}; break; }
  } else {
    float x = rnd((int)(l + 20), (int)(r - 20));
    for (int i = 0; i < 3; i++) for (auto &o : objs) if (!o.on) { o = {x + (i - 1) * 10.f, -10.f - i * 16, 5, 0, 2, true}; break; }
  }
}

static void step() {
  animT++;
  for (auto &p : pops) if (p.t > 0) { p.t--; p.y -= 0.5f; }
  for (auto &s : spl) if (s.t > 0) s.t--;
  if (shake > 0) shake--;
  if (state == PAUSED) return;
  float sp = state == PLAY ? spd : (state == TITLE ? 1.2f : spd * 0.97f);
  if (state == OVER) { endT++; spd *= 0.97f; sp = spd; }
  off += sp; dist += sp;
  while (off >= SEGH) { off -= SEGH; memmove(&seg[1], &seg[0], sizeof(Seg) * (NSEG - 1)); makeSeg(seg[0]); }
  for (auto &o : objs) if (o.on) { o.y += sp; if (o.y > SCR_H + 30) o.on = false; }
  if (state != PLAY) { if (state == TITLE) { float l, r, c; edges(BY, l, r, c); bx += (c - bx) * 0.05f; } return; }
  steps++;
  tilt::update();
  float t = tilt::x(); if (fabsf(t) < 0.06f) t = 0; else t = t > 0 ? t - 0.06f : t + 0.06f;
  bv += (t * 4.0f - bv) * 0.2f; bx += bv;
  float l, r, c; edges(BY, l, r, c);
  if (bx < l + 8) { bx = l + 8; bv = fabsf(bv) * 0.3f; spd *= 0.99f; if ((animT & 3) == 0) splash(bx - 6, BY); }
  if (bx > r - 8) { bx = r - 8; bv = -fabsf(bv) * 0.3f; spd *= 0.99f; if ((animT & 3) == 0) splash(bx + 6, BY); }
  float base = 1.8f + steps * 0.0007f; if (base > 3.9f) base = 3.9f;
  spd += (base - spd) * 0.03f;
  tgtW = 104 - fminf(32.f, steps / 70.f);
  score = (uint32_t)(dist / 10) + bonus;
  if (invul > 0) invul--;
  spawnAcc += spd;
  float gap = 56 - spd * 4; if (gap < 34) gap = 34;
  if (spawnAcc >= gap) { spawnAcc -= gap; spawnObj(); }
  for (auto &o : objs) if (o.on) {
    bool hit = false;
    for (int k = -1; k <= 1; k++) {
      float py = BY + k * 8, dx, dy;
      if (o.type == 1) {                              // tronc = capsule
        float ca = cosf(o.b), sa = sinf(o.b), x1 = o.x - ca * o.a, y1 = o.y - sa * o.a, x2 = o.x + ca * o.a, y2 = o.y + sa * o.a;
        float vx = x2 - x1, vy = y2 - y1, u = ((bx - x1) * vx + (py - y1) * vy) / (vx * vx + vy * vy); u = clampf(u, 0, 1);
        dx = bx - (x1 + vx * u); dy = py - (y1 + vy * u);
        if (dx * dx + dy * dy < 7.5f * 7.5f) hit = true;
      } else {
        dx = bx - o.x; dy = py - o.y; float rr = o.a + (o.type == 2 ? 6.0f : 3.5f);
        if (dx * dx + dy * dy < rr * rr) hit = true;
      }
    }
    if (!hit) continue;
    if (o.type == 2) { o.on = false; bonus += 10; pop(bx, BY - 26, "+10", rgb(255, 230, 90)); sfx(1400, 30); sfx(1900, 50, false); continue; }
    if (invul) continue;
    o.on = false; splash(bx, BY - 8); splash(bx - 8, BY); splash(bx + 8, BY);
    if (--lives <= 0) { gameOver(); return; }
    invul = 90; shake = 12; spd *= 0.6f; pop(bx, BY - 26, L("OUCH!","AIE !"), rgb(255, 90, 60)); sfx(160, 100); sfx(100, 160, false);
  }
}

// --------------------------------------------------------------------------- dessin
static uint32_t hash(uint32_t v) { v *= 2654435761u; v ^= v >> 15; v *= 2246822519u; return v ^ (v >> 13); }

static void drawTree(int x, int y) { canvas.fillCircle(x + 3, y + 3, 8, rgb(20, 70, 36)); canvas.fillCircle(x, y, 8, rgb(30, 110, 50)); canvas.fillCircle(x - 2, y - 2, 5, rgb(50, 145, 70)); canvas.fillCircle(x - 3, y - 3, 2, rgb(110, 190, 110)); }
static void drawBush(int x, int y) { canvas.fillCircle(x, y, 5, rgb(40, 125, 56)); canvas.fillCircle(x - 2, y - 1, 3, rgb(70, 160, 80)); canvas.fillCircle(x + 3, y - 2, 1, rgb(230, 90, 120)); }
static void drawBoulder(int x, int y) { canvas.fillEllipse(x + 1, y + 1, 7, 5, rgb(70, 74, 70)); canvas.fillEllipse(x, y, 6, 4, rgb(125, 130, 135)); canvas.fillEllipse(x - 1, y - 1, 3, 2, rgb(170, 175, 180)); }
static void drawReeds(int x, int y) { for (int i = -3; i <= 3; i += 2) canvas.drawLine(x + i, y + 4, x + i + (i > 0 ? 1 : -1), y - 6, rgb(90, 150, 60)); canvas.fillRect(x - 1, y - 8, 2, 4, rgb(120, 80, 40)); }

static void drawRock(int x, int y, int r) {
  int f = (animT / 6) & 1;
  canvas.fillEllipse(x, y + 1, r + 4 + f, r + 3, rgb(150, 205, 240));          // ecume
  canvas.fillEllipse(x + 1, y + 2, r, r - 1, rgb(40, 60, 70));
  canvas.fillCircle(x, y, r, rgb(112, 118, 125)); canvas.fillCircle(x - r / 3, y - r / 3, r / 2, rgb(165, 172, 180)); canvas.fillCircle(x + r / 3, y + r / 3, r / 3, rgb(88, 94, 100));
}
static void drawLog(const Obj &o) {
  float ca = cosf(o.b), sa = sinf(o.b);
  int x1 = (int)(o.x - ca * o.a), y1 = (int)(o.y - sa * o.a), x2 = (int)(o.x + ca * o.a), y2 = (int)(o.y + sa * o.a);
  for (int k = -2; k <= 2; k++) canvas.drawLine(x1 + k, y1, x2 + k, y2, k == -2 || k == 2 ? rgb(80, 50, 28) : (k == 0 ? rgb(150, 100, 56) : rgb(120, 78, 42)));
  canvas.fillCircle(x2, y2, 3, rgb(200, 160, 100)); canvas.drawCircle(x2, y2, 1, rgb(140, 100, 60)); canvas.fillCircle(x1, y1, 3, rgb(95, 62, 34));
  canvas.drawLine(x1 - 3, y1 + 4, x2 - 3, y2 + 4, rgb(150, 205, 240));
}
static void drawCoin(int x, int y) {
  int bob = (int)(sinf(animT * 0.2f + x) * 1.5f);
  canvas.fillCircle(x, y + bob, 5, rgb(180, 120, 20)); canvas.fillCircle(x, y + bob, 4, rgb(255, 205, 50)); canvas.drawCircle(x, y + bob, 2, rgb(220, 150, 30)); canvas.drawPixel(x - 2, y + bob - 2, TFT_WHITE);
}
static void drawKayak(int x, int y, float lean) {
  int l = (int)(lean * 2);
  // sillage
  for (int k = 1; k < 5; k++) { int w = 4 + k * 3; canvas.drawPixel(x - w - l, y + 8 + k * 4, rgb(200, 230, 250)); canvas.drawPixel(x + w - l, y + 8 + k * 4, rgb(200, 230, 250)); canvas.drawFastHLine(x - w - l, y + 8 + k * 4, 2, rgb(190, 225, 248)); canvas.drawFastHLine(x + w - l - 1, y + 8 + k * 4, 2, rgb(190, 225, 248)); }
  canvas.fillEllipse(x + 1, y + 2, 6, 13, rgb(30, 70, 120));                                  // ombre
  canvas.fillEllipse(x, y, 5, 13, rgb(245, 120, 30));                                         // coque
  canvas.fillTriangle(x - 3, y - 8, x + 3, y - 8, x, y - 17, rgb(245, 120, 30));              // proue
  canvas.fillTriangle(x - 3, y + 8, x + 3, y + 8, x, y + 16, rgb(245, 120, 30));              // poupe
  canvas.fillRect(x - 1, y - 16, 2, 28, rgb(255, 200, 90));
  canvas.fillEllipse(x, y - 1, 3, 5, rgb(40, 40, 50));                                        // cockpit
  int ph = (animT / 7) & 1;                                                                    // pagaie
  int dx = ph ? 1 : -1;
  canvas.drawLine(x - 11 * dx, y - 5 + ph * 5, x + 11 * dx, y + 1 - ph * 5, rgb(210, 210, 215));
  canvas.fillEllipse(x - 11 * dx, y - 5 + ph * 5, 2, 3, rgb(60, 80, 110)); canvas.fillEllipse(x + 11 * dx, y + 1 - ph * 5, 2, 3, rgb(60, 80, 110));
  canvas.fillEllipse(x, y, 4, 3, rgb(230, 60, 60));                                           // gilet
  canvas.fillCircle(x, y - 3, 3, rgb(250, 215, 60)); canvas.fillRect(x - 3, y - 4, 6, 1, rgb(60, 60, 70));       // casque
}

static void render() {
  int ox = shake > 0 ? (int)rnd(0, 2) - 1 : 0;
  for (int y = 0; y < SCR_H; y++) {
    float l, r, c; edges(y, l, r, c);
    int li = (int)l, ri = (int)r;
    canvas.drawFastHLine(0, y, SCR_W, rgb(48, 128, 60));
    if (((y + (int)off) / 12) & 1) canvas.drawFastHLine(0, y, li - 6, rgb(44, 120, 56));
    canvas.drawFastHLine(li - 6, y, 6, rgb(222, 200, 140)); canvas.drawFastHLine(ri, y, 6, rgb(222, 200, 140));
    uint32_t wr = (uint32_t)((int)dist - y + 100000);
    uint16_t water = ((wr / 16) & 1) ? rgb(36, 112, 198) : rgb(40, 120, 206);
    canvas.drawFastHLine(li, y, ri - li, water);
    uint32_t h = hash(wr);
    if ((h & 7) == 0) { int dx = li + 6 + (int)((h >> 8) % (uint32_t)(ri - li - 24 > 1 ? ri - li - 24 : 1)); canvas.drawFastHLine(dx, y, 6 + (int)((h >> 4) & 7), rgb(86, 160, 228)); }
    if (((wr + animT / 4) & 7) < 2) { canvas.drawPixel(li + 1, y, rgb(215, 235, 250)); canvas.drawPixel(ri - 2, y, rgb(215, 235, 250)); }
    canvas.drawPixel(li, y, rgb(190, 225, 245)); canvas.drawPixel(ri - 1, y, rgb(190, 225, 245));
  }
  // decor des berges
  for (int i = 0; i < NSEG; i++) {
    int y = i * SEGH - SEGH + (int)off + 1; float l, r, c; edges(y, l, r, c);
    for (int side = 0; side < 2; side++) {
      int t = side ? seg[i].dr : seg[i].dl; if (!t) continue; int o = side ? seg[i].orr : seg[i].ol;
      int x = side ? (int)r + 8 + o : (int)l - 8 - o;
      if (x < -10 || x > SCR_W + 10) continue;
      if (t == 1) drawTree(x, y); else if (t == 2) drawBush(x, y); else if (t == 3) drawBoulder(x, y); else drawReeds(x, y);
    }
  }
  // objets
  for (auto &o : objs) if (o.on) { if (o.type == 0) drawRock((int)o.x, (int)o.y, (int)o.a); else if (o.type == 1) drawLog(o); else drawCoin((int)o.x, (int)o.y); }
  for (auto &s : spl) if (s.t > 0) { int k = 14 - s.t; for (int a = 0; a < 5; a++) canvas.drawPixel((int)s.x + (a - 2) * (1 + k / 2), (int)s.y - k + (a & 1) * 2, TFT_WHITE); }
  if (state != OVER || (animT & 8)) if (invul == 0 || (animT & 4)) drawKayak((int)bx + ox, BY, bv / 4.0f);
  for (auto &p : pops) if (p.t > 0) txtO(p.s, (int)p.x, (int)p.y, &fonts::Font2, p.col, rgb(0, 0, 0), textdatum_t::top_center);
  char b[24];
  if (state != TITLE) {
    snprintf(b, sizeof b, "%lu", (unsigned long)score); txtO(b, 5, 2, &fonts::Font4, TFT_WHITE, rgb(10, 30, 60));
    for (int i = 0; i < lives; i++) { int hx = SCR_W - 12 - i * 14; canvas.fillEllipse(hx, 9, 3, 6, rgb(245, 120, 30)); canvas.drawFastVLine(hx, 4, 11, rgb(255, 200, 90)); }
  }
  if (state == TITLE) {
    canvas.fillRoundRect(40, 30, 160, 50, 8, rgb(12, 36, 70)); canvas.drawRoundRect(40, 30, 160, 50, 8, rgb(150, 205, 240));
    txt(L("RIVER","RIVIERE"), SCR_W / 2, 34, &fonts::Font4, rgb(255, 215, 90), textdatum_t::top_center, 1.2f);
    if (best > 0) { snprintf(b, sizeof b, L("best %lu","record %lu"), (unsigned long)best); txt(b, SCR_W / 2, 64, &fonts::Font2, rgb(200, 225, 250), textdatum_t::top_center); }
  }
  if (state == PAUSED) { canvas.fillRoundRect(80, 46, 80, 28, 5, rgb(12, 36, 70)); txt("PAUSE", SCR_W / 2, 50, &fonts::Font4, TFT_WHITE, textdatum_t::top_center); }
  if (state == OVER) {
    canvas.fillRoundRect(36, 28, 168, 60, 6, rgb(12, 36, 70)); canvas.drawRoundRect(36, 28, 168, 60, 6, rgb(235, 90, 70));
    txt(L("CAPSIZED!","CHAVIRE !"), SCR_W / 2, 32, &fonts::Font4, rgb(255, 120, 90), textdatum_t::top_center);
    snprintf(b, sizeof b, L("%lu   best %lu","%lu   record %lu"), (unsigned long)score, (unsigned long)best); txt(b, SCR_W / 2, 62, &fonts::Font2, TFT_WHITE, textdatum_t::top_center);
  }
}

void loop() {
  uint32_t now = micros();
  if (last == 0) last = now;
  acc += now - last; last = now; if (acc > 100000) acc = 100000;
  bool a = M5.BtnA.wasPressed(), p = M5.BtnPWR.wasPressed();
  switch (state) {
    case TITLE: if (a) { reset(); state = PLAY; sfx(660, 40); } break;
    case PLAY: if (p) { state = PAUSED; sfx(440, 50); } break;
    case PAUSED: if (p || a) { state = PLAY; sfx(660, 50); } break;
    case OVER: if (a && endT > 40) { reset(); state = PLAY; sfx(660, 40); } break;
  }
  while (acc >= STEP_US) { step(); acc -= STEP_US; }
  render();
  canvas.pushSprite(0, 0);
}

void icon(int x, int y) {
  canvas.fillRoundRect(x, y, 64, 64, 6, rgb(36, 112, 198));
  for (int j = 0; j < 64; j++) { int l = 10 + (int)(sinf(j * 0.12f) * 6), r = 54 + (int)(sinf(j * 0.12f) * 6); if (r > 63) r = 63; canvas.drawFastHLine(x, y + j, l, rgb(48, 128, 60)); canvas.drawFastHLine(x + l, y + j, 3, rgb(222, 200, 140)); canvas.drawFastHLine(x + r - 3, y + j, 3, rgb(222, 200, 140)); canvas.drawFastHLine(x + r, y + j, 64 - r, rgb(48, 128, 60)); }
  for (int k = 0; k < 6; k++) canvas.drawFastHLine(x + 16 + (k * 13) % 26, y + 6 + k * 10, 8, rgb(86, 160, 228));
  canvas.fillCircle(x + 42, y + 14, 6, rgb(112, 118, 125)); canvas.fillCircle(x + 40, y + 12, 3, rgb(165, 172, 180));
  canvas.fillCircle(x + 22, y + 22, 4, rgb(255, 205, 50)); canvas.drawCircle(x + 22, y + 22, 2, rgb(220, 150, 30));
  drawKayak(x + 32, y + 44, 0.3f);
}

}  // namespace river
