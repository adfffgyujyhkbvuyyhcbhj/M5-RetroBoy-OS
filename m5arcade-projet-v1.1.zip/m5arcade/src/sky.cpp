// ============================================================================
//  AVION - vol en pseudo-3D. M5 a l'horizontale : pencher = virer / monter / descendre.
//  M5 (A) maintenu = turbo ; B (cote) maintenu = frein ; HAUT (PWR) = pause
//  Passe dans les anneaux dores, evite les tours et le sol, ramasse les orbes bleus (turbo plein).
// ============================================================================
#include "common.h"

namespace sky {

static const uint32_t STEP_US = 20000;
static const float F = 105.0f;                 // focale
static const int   HZ = 46;                    // ligne d'horizon
static const float TILE = 28.0f;
static const float NEAR_Z = 9.0f, FAR_Z = 460.0f;
static const float RING_R = 14.0f, TOWER_W = 6.0f;

static const uint16_t SKY0 = rgb(16, 22, 84), SKY1 = rgb(118, 70, 150), HAZE = rgb(255, 172, 118);
static const uint16_t G1 = rgb(58, 156, 64), G2 = rgb(42, 128, 54), ROAD = rgb(96, 98, 112);

enum State { TITLE, PLAY, PAUSED, OVER };
static State state = TITLE;
static Preferences pr;
static uint32_t last = 0, acc = 0;

struct Obj { float x, y, z; uint8_t type; bool done, on; };      // 0 anneau, 1 tour (y = hauteur), 2 orbe turbo
static Obj objs[16];
struct Pop { float y; int t; char s[10]; uint16_t col; }; static Pop pops[3];
static float cloudX[4] = {20, 90, 160, 230}, cloudY[4] = {8, 22, 12, 28};

static float camX = 0, alt = 24, vx = 0, vy = 0, speed = 2.1f, boost = 100, roll = 0, camZ = 0, spawnAcc = 0, lastRx = 0, lastRy = 24;
static int lives = 3, invul = 0, combo = 0, steps = 0, animT = 0, endT = 0;
static uint32_t score = 0, best = 0, bonus = 0;
static bool boosting = false, boostLock = false, needRelease = true;

static void pop(const char* s, uint16_t col) { for (auto &p : pops) if (p.t <= 0) { p.y = 58; p.t = 40; p.col = col; strncpy(p.s, s, 9); p.s[9] = 0; return; } }
static void put(float x, float y, float z, uint8_t t) { for (auto &o : objs) if (!o.on) { o = {x, y, z, t, false, true}; return; } }

static void spawnAt(float z) {
  int towerP = 28 + (steps / 60 > 20 ? 20 : steps / 60);
  if ((int)rnd(0, 99) < towerP) {
    int n = rnd(0, 99) < 35 ? 2 : 1;
    for (int i = 0; i < n; i++) put((float)((int)rnd(0, 130) - 65), (float)(22 + (int)rnd(0, 36)), z + i * 14, 1);
  } else {
    lastRx = clampf(lastRx + (int)rnd(0, 56) - 28, -48, 48);
    lastRy = clampf(lastRy + (int)rnd(0, 30) - 15, 13, 44);
    put(lastRx, lastRy, z, 0);
    if (rnd(0, 99) < 14) put(clampf(lastRx + (int)rnd(0, 40) - 20, -55, 55), clampf(lastRy + (int)rnd(0, 16) - 8, 10, 48), z + 45, 2);
  }
}

static void reset() {
  camX = 0; alt = 24; vx = vy = 0; speed = 2.1f; boost = 100; roll = 0; camZ = 0; spawnAcc = 0; lastRx = 0; lastRy = 24;
  lives = 3; invul = 0; combo = 0; steps = 0; endT = 0; score = 0; bonus = 0; boosting = false; boostLock = false; needRelease = true;
  for (auto &o : objs) o.on = false;
  for (auto &p : pops) p.t = 0;
  for (float z = 150; z <= 450; z += 100) spawnAt(z);
}
void begin() {
  pr.begin("sky", false); best = pr.getInt("best", 0);
  reset(); state = TITLE; last = 0; acc = 0;
}

static void gameOver() {
  state = OVER; endT = 0;
  if (score > best) { best = score; pr.putInt("best", best); }
  sfx(300, 120); sfx(120, 380, false);
}
static void crash() {
  if (--lives <= 0) { gameOver(); return; }
  invul = 110; combo = 0; alt = 26; vy = 0; speed = 1.6f; boost = boost < 50 ? 50 : boost;
  for (auto &o : objs) if (o.on && o.z < 160) o.on = false;
  pop(L("BOOM!","BOUM !"), rgb(240, 80, 60)); sfx(180, 90); sfx(100, 160, false);
}
static float dz(float v) { return fabsf(v) < 0.07f ? 0 : (v > 0 ? v - 0.07f : v + 0.07f); }

static void step() {
  animT++;
  for (auto &p : pops) if (p.t > 0) { p.t--; p.y -= 0.5f; }
  if (state == PAUSED) return;
  if (state == TITLE) { camZ += 1.6f; camX = sinf(animT * 0.02f) * 30; alt = 24 + sinf(animT * 0.03f) * 4; roll = cosf(animT * 0.02f) * 0.5f; return; }
  if (state == OVER) { endT++; speed *= 0.97f; camZ += speed; roll += 0.06f; for (auto &o : objs) if (o.on) o.z -= speed; return; }
  // ----- PLAY -----
  tilt::update();
  steps++;
  float tx = dz(tilt::x()), ty = dz(tilt::y());
  vx += (tx * 3.4f - vx) * 0.2f; vy += (-ty * 2.6f - vy) * 0.2f;
  camX = clampf(camX + vx, -78, 78); alt = clampf(alt + vy, 2.5f, 72);
  roll += (clampf(vx / 3.0f, -1, 1) - roll) * 0.15f;
  bool a = M5.BtnA.isPressed(), b = M5.BtnB.isPressed();
  if (!a) needRelease = false;
  if (boost <= 0) boostLock = true;
  if (boost >= 25) boostLock = false;
  boosting = a && !needRelease && !boostLock && !b;
  if (boosting) { boost -= 1.0f; if ((steps & 7) == 0) sfx(330 + (steps & 15) * 6, 30, false); }
  else if (boost < 100) boost += a ? 0.1f : 0.24f;
  float base = 2.1f + (steps * 0.0006f > 1.5f ? 1.5f : steps * 0.0006f);
  float target = boosting ? base * 1.75f : (b ? base * 0.6f : base);
  speed += (target - speed) * 0.08f;
  camZ += speed; score = (uint32_t)(camZ / 12.0f) + bonus;
  spawnAcc += speed;
  float gap = 100 - (steps * 0.01f > 25 ? 25 : steps * 0.01f);
  if (spawnAcc >= gap) { spawnAcc -= gap; spawnAt(FAR_Z); }
  if (invul > 0) invul--;
  for (auto &o : objs) if (o.on) {
    o.z -= speed;
    if (!o.done && o.z <= NEAR_Z) {
      o.done = true;
      float dx = o.x - camX, dy = o.y - alt;
      if (o.type == 0) {
        float d = sqrtf(dx * dx + dy * dy);
        if (d < RING_R - 2) {
          combo++; int c = combo > 8 ? 8 : combo; int pts = 10 + c * 5 + (d < 4 ? 15 : 0); bonus += pts;
          char s[10]; snprintf(s, sizeof s, d < 4 ? "TOP +%d" : "+%d", pts); pop(s, rgb(255, 210, 50));
          sfx(900 + c * 110, 40); sfx(1350 + c * 110, 60, false);
        } else { combo = 0; pop(L("MISS","RATE"), rgb(255, 255, 255)); sfx(240, 90); }
      } else if (o.type == 1) {
        if (invul == 0 && fabsf(dx) < TOWER_W + 3 && alt < o.y + 2) { o.on = false; crash(); if (state != PLAY) return; }
      } else {
        if (fabsf(dx) < 10 && fabsf(dy) < 10) { boost = 100; boostLock = false; bonus += 5; pop("TURBO", rgb(90, 220, 255)); sfx(1500, 40); sfx(2000, 70, false); }
      }
    }
    if (o.z < 2) o.on = false;
  }
  if (alt <= 3.2f && invul == 0) { crash(); if (state != PLAY) return; }
}

// ---------------------------------------------------------------------------
static void drawPlane(int px, int py, float rl, bool flame, float k, bool blink = false) {
  if (blink) return;
  uint16_t body = rgb(236, 240, 250), shade = rgb(150, 160, 190), dk = rgb(50, 56, 90), red = rgb(228, 62, 62), cock = rgb(90, 190, 255);
  int wy = (int)(rl * 9 * k), tip = (int)(26 * k), rt = (int)(3 * k);
  int ly = py + (int)(5 * k) - wy, ry = py + (int)(5 * k) + wy;
  if (flame) { int fy = py + (int)(10 * k); canvas.fillCircle(px, fy, (int)(4 * k) + (animT & 1), rgb(255, 150, 40)); canvas.fillCircle(px, fy, (int)(2 * k) + 1, rgb(255, 240, 160)); }
  canvas.fillTriangle(px - rt, py - (int)(1 * k), px - rt, py + (int)(8 * k), px - tip, ly + (int)(3 * k), body);
  canvas.fillTriangle(px + rt, py - (int)(1 * k), px + rt, py + (int)(8 * k), px + tip, ry + (int)(3 * k), body);
  canvas.fillTriangle(px - rt, py + (int)(3 * k), px - rt, py + (int)(8 * k), px - tip, ly + (int)(3 * k), shade);
  canvas.fillTriangle(px + rt, py + (int)(3 * k), px + rt, py + (int)(8 * k), px + tip, ry + (int)(3 * k), shade);
  canvas.drawLine(px - rt, py - (int)(1 * k), px - tip, ly + (int)(3 * k), dk); canvas.drawLine(px + rt, py - (int)(1 * k), px + tip, ry + (int)(3 * k), dk);
  canvas.fillCircle(px - tip, ly + (int)(3 * k), (int)(2 * k) + 1, red); canvas.fillCircle(px + tip, ry + (int)(3 * k), (int)(2 * k) + 1, red);
  canvas.fillTriangle(px - (int)(2 * k), py + (int)(1 * k), px + (int)(2 * k), py + (int)(1 * k), px, py - (int)(11 * k), red);            // derive
  canvas.fillEllipse(px, py + (int)(2 * k), (int)(5 * k), (int)(8 * k), body);
  canvas.fillEllipse(px, py + (int)(5 * k), (int)(4 * k), (int)(4 * k), shade);
  canvas.fillEllipse(px, py - (int)(1 * k), (int)(2 * k) + 1, (int)(3 * k) + 1, cock);
}

static void drawRing(int sx, int sy, float s, float z, bool next) {
  int r = (int)(RING_R * s); if (r < 2) return;
  int th = r / 7 + 1; if (th > 6) th = 6;
  int t = (int)((z - 120) * 256 / (FAR_Z - 120)); if (t < 0) t = 0; if (t > 256) t = 256;
  uint16_t c = next ? ((animT & 8) ? rgb(255, 255, 255) : rgb(120, 240, 255)) : rgb(255, 196, 40);
  c = mixc(c, HAZE, t);
  for (int k = 0; k < th; k++) canvas.drawCircle(sx, sy, r - k, c);
  if (th > 2) canvas.drawCircle(sx, sy, r + 1, mixc(rgb(150, 90, 10), HAZE, t));
}
static void drawTower(int sx, float s, float z, float h) {
  int t = (int)((z - 120) * 256 / (FAR_Z - 120)); if (t < 0) t = 0; if (t > 256) t = 256;
  int w = (int)(TOWER_W * s); if (w < 1) w = 1;
  int top = HZ + (int)((alt - h) * s), bot = HZ + (int)(alt * s);
  if (bot <= top) return;
  uint16_t c1 = mixc(rgb(214, 72, 72), HAZE, t), c2 = mixc(rgb(150, 44, 56), HAZE, t), cw = mixc(rgb(240, 240, 240), HAZE, t);
  canvas.fillRect(sx - w, top, w * 2 * 6 / 10, bot - top, c1);
  canvas.fillRect(sx - w + w * 2 * 6 / 10, top, w * 2 - w * 2 * 6 / 10, bot - top, c2);
  int bands = 4; for (int i = 1; i < bands; i += 2) canvas.fillRect(sx - w, top + (bot - top) * i / bands, w * 2, (bot - top) / bands, cw);
  canvas.fillRect(sx - w - 1, top - 2, w * 2 + 2, 3, mixc(rgb(90, 20, 30), HAZE, t));
  if (animT & 8) canvas.fillCircle(sx, top - 4, w / 3 + 1, rgb(255, 255, 120));
}
static void drawOrb(int sx, int sy, float s) {
  int r = (int)(5 * s); if (r < 2) return;
  canvas.fillCircle(sx, sy, r + 2, rgb(30, 120, 190)); canvas.fillCircle(sx, sy, r, rgb(90, 220, 255)); canvas.fillCircle(sx - r / 3, sy - r / 3, r / 3 + 1, TFT_WHITE);
}

static void renderSky() {
  for (int y = 0; y < HZ; y++) { int t = y * 256 / HZ; uint16_t c = t < 150 ? mixc(SKY0, SKY1, t * 256 / 150) : mixc(SKY1, HAZE, (t - 150) * 256 / 106); canvas.drawFastHLine(0, y, SCR_W, c); }
  int sunX = 170 - (int)(camX * 0.25f);
  canvas.fillCircle(sunX, HZ - 14, 18, mixc(SKY1, HAZE, 170)); canvas.fillCircle(sunX, HZ - 14, 12, rgb(255, 238, 176));
  for (int i = 0; i < 4; i++) { cloudX[i] += 0.1f * (i + 1) * 0.5f; if (cloudX[i] > SCR_W + 60) cloudX[i] = -60; }
  for (int i = 0; i < 4; i++) { int cx = (int)(cloudX[i] - camX * 0.4f); int cy = (int)cloudY[i]; uint16_t cc = mixc(rgb(255, 214, 200), SKY1, 60); canvas.fillRoundRect(cx, cy, 34, 7, 3, cc); canvas.fillCircle(cx + 11, cy, 5, cc); canvas.fillCircle(cx + 21, cy + 1, 4, cc); }
  for (int layer = 0; layer < 2; layer++) {
    float off = camX * (0.5f + layer * 0.5f) + layer * 57; uint16_t c = layer ? rgb(78, 54, 118) : rgb(130, 90, 150);
    for (int x = 0; x < SCR_W; x += 2) {
      float u = (x + off) * (layer ? 0.05f : 0.035f);
      int h = (int)((layer ? 9 : 15) + (layer ? 5 : 8) * sinf(u) + (layer ? 3 : 5) * sinf(u * 2.7f + layer)); if (h < 1) h = 1;
      canvas.fillRect(x, HZ - h, 2, h, c);
    }
  }
}
static void renderGround() {
  for (int Y = HZ; Y < SCR_H; Y++) {
    if (Y == HZ) { canvas.drawFastHLine(0, Y, SCR_W, HAZE); continue; }
    float z = alt * F / (Y - HZ);
    int t = (int)((z - 60) * 256 / (FAR_Z - 60)); if (t < 0) t = 0; if (t > 256) t = 256;
    uint16_t c0 = mixc(G1, HAZE, t), c1 = mixc(G2, HAZE, t), cr = mixc(ROAD, HAZE, t);
    if (t >= 250) { canvas.drawFastHLine(0, Y, SCR_W, c0); continue; }
    int zi = (int)floorf((z + camZ) / TILE);
    bool dash = (((int)((z + camZ) / 12)) & 1) != 0;
    for (int px = 0; px < SCR_W; px += 8) {
      float wx = camX + (px + 4 - SCR_W / 2) * z / F;
      uint16_t c;
      if (fabsf(wx) < 9) c = (fabsf(wx) < 1.2f && dash) ? mixc(TFT_WHITE, HAZE, t) : cr;
      else c = (((int)floorf(wx / TILE) + zi) & 1) ? c1 : c0;
      canvas.fillRect(px, Y, 8, 1, c);
    }
  }
}

static void render() {
  renderSky();
  renderGround();
  // objets tries : les plus lointains d'abord
  int order[16], n = 0;
  for (int i = 0; i < 16; i++) if (objs[i].on && objs[i].z > NEAR_Z * 0.6f) order[n++] = i;
  for (int i = 1; i < n; i++) { int k = order[i], j = i - 1; while (j >= 0 && objs[order[j]].z < objs[k].z) { order[j + 1] = order[j]; j--; } order[j + 1] = k; }
  float nextZ = 9999; for (int i = 0; i < n; i++) { const Obj &o = objs[order[i]]; if (o.type == 0 && !o.done && o.z < nextZ) nextZ = o.z; }
  for (int k = 0; k < n; k++) {
    const Obj &o = objs[order[k]];
    float s = F / o.z; int sx = SCR_W / 2 + (int)((o.x - camX) * s);
    if (sx < -80 || sx > SCR_W + 80) continue;
    if (o.type == 0) drawRing(sx, HZ + (int)((alt - o.y) * s), s, o.z, o.z == nextZ);
    else if (o.type == 1) drawTower(sx, s, o.z, o.y);
    else drawOrb(sx, HZ + (int)((alt - o.y) * s), s);
  }
  // ombre au sol
  { float gz = 16; int gy = HZ + (int)(alt * F / gz); if (gy < SCR_H - 2 && state != TITLE) canvas.fillEllipse(SCR_W / 2 + (int)(vx * 4), gy, 14, 3, mixc(G2, TFT_BLACK, 150)); }
  if (boosting) for (int i = 0; i < 10; i++) { float ang = i * 0.628f + (animT % 5) * 0.11f; int x0 = SCR_W / 2 + (int)(cosf(ang) * 80), y0 = 70 + (int)(sinf(ang) * 46); canvas.drawLine(x0, y0, x0 + (int)(cosf(ang) * 40), y0 + (int)(sinf(ang) * 24), rgb(255, 255, 255)); }
  int px = SCR_W / 2 + (int)(vx * 5), py = 100 - (int)(vy * 4) + (state == TITLE ? 0 : 0);
  drawPlane(px, py, roll, boosting, 1.0f, invul > 0 && (animT & 4));
  // infos
  for (auto &p : pops) if (p.t > 0) txtO(p.s, SCR_W / 2, (int)p.y, &fonts::Font2, p.col, rgb(20, 20, 60), textdatum_t::top_center);
  char b[32];
  if (state != TITLE) {
    snprintf(b, sizeof b, "%lu", (unsigned long)score); txtO(b, 5, 2, &fonts::Font4, TFT_WHITE, rgb(20, 20, 70));
    if (combo >= 2) { snprintf(b, sizeof b, "x%d", combo); txtO(b, 5, 26, &fonts::Font2, rgb(255, 210, 50), rgb(20, 20, 70)); }
    for (int i = 0; i < lives; i++) { int hx = SCR_W - 12 - i * 14; canvas.fillTriangle(hx, 4, hx - 6, 14, hx + 6, 14, TFT_WHITE); canvas.fillTriangle(hx, 6, hx - 3, 12, hx + 3, 12, rgb(228, 62, 62)); }
    canvas.fillRect(5, SCR_H - 12, 62, 8, rgb(20, 20, 60)); canvas.fillRect(6, SCR_H - 11, (int)(boost * 60 / 100), 6, boostLock ? rgb(200, 70, 60) : (boosting ? rgb(255, 230, 90) : rgb(255, 150, 40)));
  }
  if (state == TITLE) {
    canvas.fillRoundRect(40, 14, 160, 52, 8, rgb(255, 255, 255)); canvas.drawRoundRect(40, 14, 160, 52, 8, rgb(30, 50, 140));
    txt(L("FLIGHT","AVION"), SCR_W / 2, 18, &fonts::Font4, rgb(30, 50, 140), textdatum_t::top_center, 1.3f);
    if (best > 0) { snprintf(b, sizeof b, L("best %lu","record %lu"), (unsigned long)best); txt(b, SCR_W / 2, 52, &fonts::Font0, rgb(200, 90, 30), textdatum_t::top_center); }
  }
  if (state == PAUSED) txtO("PAUSE", SCR_W / 2, 52, &fonts::Font4, TFT_WHITE, rgb(20, 20, 70), textdatum_t::top_center);
  if (state == OVER) {
    canvas.fillRoundRect(34, 30, 172, 66, 6, rgb(255, 255, 255)); canvas.drawRoundRect(34, 30, 172, 66, 6, rgb(230, 70, 60));
    txt("CRASH !", SCR_W / 2, 34, &fonts::Font4, rgb(230, 70, 60), textdatum_t::top_center);
    snprintf(b, sizeof b, L("score %lu  best %lu","score %lu  record %lu"), (unsigned long)score, (unsigned long)best); txt(b, SCR_W / 2, 66, &fonts::Font2, rgb(40, 50, 90), textdatum_t::top_center);
  }
}

void loop() {
  uint32_t now = micros();
  if (last == 0) last = now;
  acc += now - last; last = now; if (acc > 100000) acc = 100000;
  bool a = M5.BtnA.wasPressed(), p = M5.BtnPWR.wasPressed();
  switch (state) {
    case TITLE: if (a) { reset(); state = PLAY; sfx(660, 40); } break;
    case PLAY: if (p) { state = PAUSED; sfx(440, 50); } break;
    case PAUSED: if (p || a) { state = PLAY; sfx(660, 50); } break;
    case OVER: if (a && endT > 40) { reset(); state = PLAY; sfx(660, 40); } break;
  }
  while (acc >= STEP_US) { step(); acc -= STEP_US; }
  render();
  canvas.pushSprite(0, 0);
}

void icon(int x, int y) {
  canvas.setClipRect(x, y, 64, 64);
  for (int j = 0; j < 34; j++) { int t = j * 256 / 34; canvas.drawFastHLine(x, y + j, 64, t < 150 ? mixc(SKY0, SKY1, t * 256 / 150) : mixc(SKY1, HAZE, (t - 150) * 256 / 106)); }
  canvas.fillCircle(x + 46, y + 28, 9, rgb(255, 238, 176));
  canvas.fillTriangle(x, y + 34, x + 14, y + 22, x + 30, y + 34, rgb(78, 54, 118)); canvas.fillTriangle(x + 20, y + 34, x + 38, y + 20, x + 58, y + 34, rgb(110, 76, 140));
  canvas.fillRect(x, y + 34, 64, 30, G1);
  for (int i = 1; i < 6; i++) canvas.fillRect(x, y + 34 + i * i, 64, i, G2);
  canvas.fillTriangle(x + 27, y + 34, x + 37, y + 34, x + 50, y + 64, ROAD); canvas.fillTriangle(x + 27, y + 34, x + 50, y + 64, x + 14, y + 64, ROAD);
  for (int k = 0; k < 3; k++) canvas.drawCircle(x + 38, y + 25, 12 - k, rgb(255, 196, 40));
  drawPlane(x + 28, y + 46, 0.3f, true, 0.8f);
  canvas.clearClipRect();
}

}  // namespace sky
