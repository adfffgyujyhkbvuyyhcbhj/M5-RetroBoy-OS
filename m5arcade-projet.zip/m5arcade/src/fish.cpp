// ============================================================================
//  POISSON - mange les plus petits, fuis les plus gros ! Penche le M5 dans tous les sens pour nager.
//  HAUT = pause
// ============================================================================
#include "common.h"

namespace fish {

static const uint32_t STEP_US = 20000;
static const int TOP = 16, FLOOR = 122;
enum State { TITLE, PLAY, PAUSED, OVER };
static State state = TITLE;
static Preferences pr;
static uint32_t last = 0, acc = 0;

struct Fish { float x, y, vx, s, ph; uint8_t hue; bool on; };
static Fish fs[12];
struct Bub { float x, y, r, v; }; static Bub bubs[14];
struct Pop { float x, y; int t; char s[10]; uint16_t col; }; static Pop pops[3];

static float fx = 120, fy = 70, fvx = 0, fvy = 0, ps = 7;
static int dirP = 1, lives = 3, level = 1, invul = 0, endT = 0, animT = 0, spawnT = 0, growT = 0, eaten = 0;
static uint32_t score = 0, best = 0;

static const uint16_t HUES[6] = {rgb(70, 190, 120), rgb(90, 170, 240), rgb(240, 200, 60), rgb(170, 110, 230), rgb(120, 220, 200), rgb(240, 130, 170)};

static void pop(float x, float y, const char* s, uint16_t col) { for (auto &p : pops) if (p.t <= 0) { p.x = x; p.y = y; p.t = 36; p.col = col; strncpy(p.s, s, 9); p.s[9] = 0; return; } }
static void bubble(float x, float y, int n) { for (int i = 0; i < n; i++) for (auto &b : bubs) if (b.y < -4) { b = {x + (int)rnd(0, 8) - 4, y + (int)rnd(0, 6) - 3, (float)rnd(1, 3), rnd(6, 16) / 10.f}; break; }
}

static void reset() {
  fx = 120; fy = 70; fvx = fvy = 0; ps = 7; dirP = 1; lives = 3; level = 1; invul = 0; endT = 0; spawnT = 20; score = 0; eaten = 0; growT = 0;
  for (auto &f : fs) f.on = false;
  for (auto &p : pops) p.t = 0;
  for (auto &b : bubs) b = {(float)rnd(0, SCR_W), (float)rnd(0, SCR_H), (float)rnd(1, 3), rnd(6, 16) / 10.f};
}
void begin() {
  pr.begin("fish", false); best = pr.getInt("best", 0);
  tilt::load();
  reset(); state = TITLE; last = 0; acc = 0;
}
static void gameOver() {
  state = OVER; endT = 0;
  if (score > best) { best = score; pr.putInt("best", best); }
  sfx(300, 120); sfx(120, 320, false);
}

static void spawn() {
  for (auto &f : fs) if (!f.on) {
    float s;
    if (rnd(0, 99) < 62) s = ps * (0.35f + rnd(0, 55) * 0.01f);       // proie
    else s = ps * (1.1f + rnd(0, 80) * 0.01f);                         // predateur
    if (s < 4) s = 4; if (s > 42) s = 42;
    bool left = rnd(0, 1);
    float sp = (0.6f + rnd(0, 10) * 0.1f) * (1.0f + level * 0.08f) * (1.4f - s * 0.015f); if (sp < 0.4f) sp = 0.4f;
    f = {left ? -s * 2 : SCR_W + s * 2, (float)rnd(TOP + (int)s, FLOOR - (int)s - 2), left ? sp : -sp, s, rnd(0, 628) / 100.f, (uint8_t)rnd(0, 5), true};
    return;
  }
}

static void step() {
  animT++;
  for (auto &p : pops) if (p.t > 0) { p.t--; p.y -= 0.5f; }
  for (auto &b : bubs) { b.y -= b.v; b.x += sinf(b.y * 0.1f) * 0.3f; if (b.y < -4) { b.y = SCR_H + 4; b.x = rnd(0, SCR_W); } }
  if (state == PAUSED) return;
  if (state == OVER) endT++;
  // les poissons nagent aussi dans le titre / game over
  for (auto &f : fs) if (f.on) { f.x += f.vx; f.ph += 0.08f; f.y += sinf(f.ph) * 0.25f; if (f.x < -f.s * 3 || f.x > SCR_W + f.s * 3) f.on = false; }
  if (state != PLAY) { if (--spawnT <= 0) { spawn(); spawnT = 40; } return; }
  tilt::update();
  float tx = tilt::x(), ty = -tilt::y();
  if (fabsf(tx) < 0.06f) tx = 0; if (fabsf(ty) < 0.06f) ty = 0;
  float acc_ = 0.16f;
  fvx += tx * acc_; fvy += ty * acc_; fvx *= 0.93f; fvy *= 0.93f;
  float mx = 2.6f; fvx = clampf(fvx, -mx, mx); fvy = clampf(fvy, -mx, mx);
  fx += fvx; fy += fvy;
  float a = ps, b = ps * 0.55f;
  fx = clampf(fx, a, SCR_W - a); fy = clampf(fy, TOP + b, FLOOR - b);
  if (fvx > 0.15f) dirP = 1; else if (fvx < -0.15f) dirP = -1;
  if (invul > 0) invul--;
  if (growT > 0) growT--;
  if (--spawnT <= 0) { spawn(); int T = 34 - level * 2; spawnT = T < 14 ? 14 : T; }
  if ((animT & 31) == 0) bubble(fx + dirP * ps, fy - 2, 1);
  for (auto &f : fs) if (f.on) {
    float fa = f.s, fb = f.s * 0.55f, dx = fabsf(f.x - fx), dy = fabsf(f.y - fy);
    if (dx < (a + fa) * 0.78f && dy < (b + fb) * 0.85f) {
      if (f.s <= ps * 0.98f) {                       // on le mange
        f.on = false; eaten++;
        score += (uint32_t)(f.s * 2); ps += f.s * 0.085f; growT = 14;
        bubble(f.x, f.y, 4); sfx(700 + (int)f.s * 12, 30); sfx(1000 + (int)f.s * 12, 40, false);
        char t[10]; snprintf(t, sizeof t, "+%d", (int)(f.s * 2)); pop(f.x, f.y - f.s, t, rgb(255, 235, 120));
        if (ps >= 26) { level++; ps = 8; invul = 60; pop(SCR_W / 2.f, 50, "NIVEAU SUIVANT", rgb(120, 255, 190)); sfx(988, 80); sfx(1318, 80, false); sfx(1760, 140, false); for (auto &o : fs) if (o.on && o.s > ps) o.on = false; }
      } else if (!invul) {                           // il nous mange (on perd une vie)
        if (--lives <= 0) { gameOver(); return; }
        invul = 100; ps = ps * 0.85f; if (ps < 6) ps = 6; fvx = -dirP * 2.0f; bubble(fx, fy, 6); pop(fx, fy - 14, "AIE !", rgb(255, 90, 60)); sfx(180, 100); sfx(100, 160, false);
      }
    }
  }
}

// --------------------------------------------------------------------------- dessin
static void drawFish(float x, float y, float s, int dir, uint16_t col, bool danger, bool player, float ph) {
  int a = (int)s, b = (int)(s * 0.55f); if (b < 2) b = 2;
  int xi = (int)x, yi = (int)y;
  uint16_t dark = mixc(col, 0, 90), light = mixc(col, 0xFFFF, 90);
  int wag = (int)(sinf(ph * 2.2f) * (b * 0.5f));
  // queue
  int tx = xi - dir * a;
  canvas.fillTriangle(tx + dir * 2, yi, tx - dir * (a / 2 + 2), yi - b + wag, tx - dir * (a / 2 + 2), yi + b + wag, dark);
  // nageoire dorsale + ventrale
  canvas.fillTriangle(xi - dir * a / 3, yi - b + 1, xi + dir * a / 3, yi - b + 1, xi - dir * a / 2, yi - b - b / 2 - 1, dark);
  canvas.fillTriangle(xi, yi + b - 1, xi + dir * a / 3, yi + b - 1, xi - dir * a / 5, yi + b + b / 2, dark);
  canvas.fillEllipse(xi, yi, a, b, col);
  canvas.fillEllipse(xi + dir * a / 8, yi + b / 3, a * 3 / 4, b / 2, light);                // ventre clair
  if (player) {                                                                              // bandes de poisson-clown
    for (int ox = -a; ox <= a; ox++) {
      int u = ox * dir; bool st = (u > a / 4 && u < a / 4 + a / 4 + 1) || (u > -a * 2 / 3 && u < -a * 2 / 3 + a / 4 + 1);
      float k = 1.0f - (float)(ox * ox) / (a * a); if (k <= 0) continue; int hh = (int)(b * sqrtf(k));
      if (st) canvas.drawFastVLine(xi + ox, yi - hh, hh * 2 + 1, rgb(250, 250, 250));
      bool edge = (u == a / 4 || u == a / 4 + a / 4 + 1 || u == -a * 2 / 3 || u == -a * 2 / 3 + a / 4 + 1);
      if (edge) canvas.drawFastVLine(xi + ox, yi - hh, hh * 2 + 1, rgb(40, 30, 30));
    }
  }
  // oeil
  int er = b / 3 + 1; int ex = xi + dir * (a * 5 / 8), ey = yi - b / 4;
  canvas.fillCircle(ex, ey, er, TFT_WHITE); canvas.fillCircle(ex + dir * (er > 1 ? 1 : 0), ey, er > 2 ? er - 1 : 1, danger ? rgb(220, 20, 20) : TFT_BLACK);
  // bouche
  canvas.drawLine(xi + dir * a, yi + b / 5, xi + dir * (a * 3 / 4), yi + b / 4 + 1, rgb(30, 20, 20));
  if (danger && a > 8) { for (int k = 0; k < 3; k++) canvas.drawFastVLine(xi + dir * (a - 2 - k * 2), yi + b / 5 + 1, 2, TFT_WHITE); canvas.drawLine(ex - er - 1, ey - er - 1, ex + er + 1, ey - er + (dir > 0 ? 1 : -1), rgb(30, 10, 10)); }
}

static void render() {
  for (int y = 0; y < SCR_H; y += 3) canvas.fillRect(0, y, SCR_W, 3, mixc(rgb(70, 170, 225), rgb(8, 36, 90), y * 256 / SCR_H));
  for (int i = 0; i < 4; i++) { int x0 = 20 + i * 62 + (int)(sinf(animT * 0.01f + i) * 8); canvas.fillTriangle(x0, 0, x0 + 14, 0, x0 + 44, 118, mixc(rgb(70, 170, 225), rgb(140, 210, 245), 40)); }
  for (int i = 0; i < 4; i++) { int x0 = 20 + i * 62 + (int)(sinf(animT * 0.01f + i) * 8); canvas.drawLine(x0 + 7, 0, x0 + 44, 118, mixc(rgb(70, 170, 225), rgb(190, 235, 250), 50)); }
  // sable, algues
  canvas.fillRect(0, FLOOR + 2, SCR_W, SCR_H - FLOOR, rgb(214, 190, 130));
  for (int x = 0; x < SCR_W; x += 6) canvas.fillEllipse(x + (x * 7 % 5), FLOOR + 2, 5, 3, rgb(214, 190, 130));
  for (int i = 0; i < 9; i++) { int bx = 8 + i * 28, h = 10 + (i * 5) % 14, sw = (int)(sinf(animT * 0.06f + i) * 3); for (int k = -1; k <= 1; k++) canvas.drawLine(bx + k * 2 + sw, FLOOR + 1 - h, bx + k * 2, FLOOR + 3, rgb(30, 130 + (i * 17) % 60, 70)); }
  canvas.fillEllipse(30, FLOOR + 6, 6, 3, rgb(150, 130, 90)); canvas.fillEllipse(190, FLOOR + 8, 5, 2, rgb(170, 150, 105));
  for (auto &b : bubs) { canvas.drawCircle((int)b.x, (int)b.y, (int)b.r, rgb(190, 235, 255)); canvas.drawPixel((int)b.x - 1, (int)b.y - 1, TFT_WHITE); }
  for (auto &f : fs) if (f.on) drawFish(f.x, f.y, f.s, f.vx > 0 ? 1 : -1, HUES[f.hue], state != TITLE && f.s > ps * 0.98f, false, f.ph);
  if (state != TITLE && (state != OVER || (animT & 8)) && (invul == 0 || (animT & 4))) {
    float g = growT > 0 ? 1.0f + growT * 0.01f : 1.0f;
    drawFish(fx, fy, ps * g, dirP, rgb(250, 130, 30), false, true, animT * 0.18f);
  }
  for (auto &p : pops) if (p.t > 0) txtO(p.s, (int)p.x, (int)p.y, &fonts::Font2, p.col, rgb(0, 20, 50), textdatum_t::top_center);
  char b[24];
  if (state != TITLE) {
    snprintf(b, sizeof b, "%lu", (unsigned long)score); txtO(b, 5, 0, &fonts::Font4, TFT_WHITE, rgb(0, 30, 70));
    for (int i = 0; i < lives; i++) { int hx = SCR_W - 12 - i * 14; canvas.fillEllipse(hx, 8, 4, 3, rgb(250, 130, 30)); canvas.fillTriangle(hx + 3, 8, hx + 7, 5, hx + 7, 11, rgb(250, 130, 30)); }
    canvas.drawRect(SCR_W / 2 - 30, 2, 60, 6, rgb(190, 235, 255)); canvas.fillRect(SCR_W / 2 - 29, 3, (int)(58 * clampf((ps - 7) / 19.f, 0, 1)), 4, rgb(120, 255, 190));
  }
  if (state == TITLE) {
    canvas.fillRoundRect(40, 28, 160, 52, 8, rgb(6, 30, 70)); canvas.drawRoundRect(40, 28, 160, 52, 8, rgb(150, 215, 245));
    txt("POISSON", SCR_W / 2, 32, &fonts::Font4, rgb(255, 170, 60), textdatum_t::top_center, 1.2f);
    if (best > 0) { snprintf(b, sizeof b, "record %lu", (unsigned long)best); txt(b, SCR_W / 2, 62, &fonts::Font2, rgb(200, 230, 250), textdatum_t::top_center); }
  }
  if (state == PAUSED) { canvas.fillRoundRect(80, 46, 80, 28, 5, rgb(6, 30, 70)); txt("PAUSE", SCR_W / 2, 50, &fonts::Font4, TFT_WHITE, textdatum_t::top_center); }
  if (state == OVER) {
    canvas.fillRoundRect(36, 28, 168, 60, 6, rgb(6, 30, 70)); canvas.drawRoundRect(36, 28, 168, 60, 6, rgb(235, 90, 70));
    txt("MANGE !", SCR_W / 2, 32, &fonts::Font4, rgb(255, 120, 90), textdatum_t::top_center);
    snprintf(b, sizeof b, "%lu   record %lu", (unsigned long)score, (unsigned long)best); txt(b, SCR_W / 2, 62, &fonts::Font2, TFT_WHITE, textdatum_t::top_center);
  }
}

void loop() {
  uint32_t now = micros();
  if (last == 0) last = now;
  acc += now - last; last = now; if (acc > 100000) acc = 100000;
  bool a = M5.BtnA.wasPressed(), p = M5.BtnPWR.wasPressed();
  switch (state) {
    case TITLE: if (a) { reset(); state = PLAY; sfx(660, 40); } break;
    case PLAY: if (p) { state = PAUSED; sfx(440, 50); } break;
    case PAUSED: if (p || a) { state = PLAY; sfx(660, 50); } break;
    case OVER: if (a && endT > 40) { reset(); state = PLAY; sfx(660, 40); } break;
  }
  while (acc >= STEP_US) { step(); acc -= STEP_US; }
  render();
  canvas.pushSprite(0, 0);
}

void icon(int x, int y) {
  for (int j = 0; j < 64; j += 2) canvas.fillRect(x, y + j, 64, 2, mixc(rgb(70, 170, 225), rgb(8, 36, 90), j * 4));
  canvas.fillRect(x, y + 56, 64, 8, rgb(214, 190, 130));
  drawFish(x + 20, y + 44, 10, 1, rgb(250, 130, 30), false, true, 0.5f);
  drawFish(x + 50, y + 20, 5, -1, rgb(90, 170, 240), false, false, 1.0f);
  drawFish(x + 40, y + 38, 13, -1, rgb(170, 110, 230), true, false, 2.0f);
  canvas.drawCircle(x + 10, y + 14, 3, rgb(190, 235, 255)); canvas.drawCircle(x + 16, y + 6, 2, rgb(190, 235, 255));
}

}  // namespace fish
