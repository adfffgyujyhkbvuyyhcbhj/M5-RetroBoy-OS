// ============================================================================
//  M5 ARCADE - M5StickC Plus2
//  Menu facon console + jeux. Menu : B (cote) = suivant, HAUT (PWR) = precedent, M5 (A) = lancer
//  Dans un jeu : maintenir HAUT (PWR) 1,5 s = retour au menu
// ============================================================================
#include "common.h"

M5Canvas canvas(&M5.Display);

int  g_bright = 2;
bool g_sound = true;
int  g_sleepIdx = 1;
bool g_quit = false;
static const int BRI[5] = {30, 70, 120, 180, 255};
static const uint32_t SLEEP_MS[5] = {30000, 60000, 120000, 300000, 0};
static Preferences mp;

void applyBrightness() { M5.Display.setBrightness(BRI[g_bright]); }
void saveSettings() { mp.putInt("bri", g_bright); mp.putBool("snd", g_sound); mp.putInt("slp", g_sleepIdx); }
void sfx(int freq, int ms, bool stopPrev) { if (g_sound) M5.Speaker.tone(freq, ms, -1, stopPrev); }

struct GameDef { const char* name; void (*begin)(); void (*loop)(); void (*icon)(int, int); };
static const GameDef GAMES[] = {
  {"CHROME DINO",    dino::begin,     dino::loop,     dino::icon},
  {"FLAP BIRD",      flap::begin,     flap::loop,     flap::icon},
  {"METEORES",       space::begin,    space::loop,    space::icon},
  {"LABYRINTHE",     maze::begin,     maze::loop,     maze::icon},
  {"CASSE-BRIQUES",  breakout::begin, breakout::loop, breakout::icon},
  {"INVADERS",       invaders::begin, invaders::loop, invaders::icon},
  {"SLALOM",         ski::begin,      ski::loop,      ski::icon},
  {"STACK",          stack::begin,    stack::loop,    stack::icon},
  {"COURSE",         race::begin,     race::loop,     race::icon},
  {"RIVIERE",        river::begin,    river::loop,    river::icon},
  {"POISSON",        fish::begin,     fish::loop,     fish::icon},
  {"MUSIQUE",        music::begin,    music::loop,    music::icon},
  {"REGLAGES",       settings::begin, settings::loop, settings::icon},
};
static const int NGAMES = sizeof(GAMES) / sizeof(GAMES[0]);
static int sel = 0, running = -1;
static float slide = 0;                       // animation de defilement (en tuiles)
static uint32_t lastAct = 0;                  // dernier appui (pour l'ecran de veille)
static int saver = 0;                         // 0 = normal, 1 = veille (animation), 2 = ecran eteint
static int batLevel = 100; static bool batChg = false; static uint32_t batT = 0;

// ----------------------------------------------------------------------------- menu
static void dim(int x, int y) { for (int j = 0; j < 64; j += 2) canvas.drawFastHLine(x, y + j, 64, rgb(10, 10, 18)); }

static void drawBattery(int x, int y, int lvl, bool chg) {            // petite pile facon telephone + pourcentage
  uint16_t col = lvl <= 15 ? rgb(235, 60, 60) : (lvl <= 35 ? rgb(250, 190, 40) : rgb(90, 220, 110));
  canvas.drawRoundRect(x, y, 22, 11, 3, rgb(220, 224, 240)); canvas.fillRect(x + 22, y + 3, 2, 5, rgb(220, 224, 240));
  int w = (lvl * 18) / 100; if (w < 1 && lvl > 0) w = 1;
  canvas.fillRoundRect(x + 2, y + 2, w, 7, 2, col);
  if (chg) { canvas.fillTriangle(x + 12, y + 1, x + 7, y + 6, x + 11, y + 6, rgb(255, 255, 255)); canvas.fillTriangle(x + 10, y + 5, x + 14, y + 5, x + 9, y + 10, rgb(255, 255, 255)); }
  char b[8]; snprintf(b, sizeof b, "%d%%", lvl); txt(b, x + 28, y + 1, &fonts::Font0, rgb(220, 224, 240));
}

static void drawMenu() {
  canvas.fillScreen(rgb(32, 36, 58));
  canvas.fillRect(0, 0, SCR_W, 19, rgb(16, 18, 34));
  drawBattery(5, 4, batLevel, batChg);
  txt("M5 ARCADE", SCR_W / 2 + 6, 2, &fonts::Font2, rgb(255, 210, 80), textdatum_t::top_center);
  char b[10]; snprintf(b, sizeof b, "%d/%d", sel + 1, NGAMES); txt(b, SCR_W - 5, 6, &fonts::Font0, rgb(150, 160, 200), textdatum_t::top_right);
  for (int d = -1; d <= 1; d++) {
    int idx = (sel + d + NGAMES) % NGAMES;
    float px = SCR_W / 2 - 32 + (d - slide) * 82;
    int ix = (int)px, iy = 27 + (d == 0 ? (int)(sinf(millis() * 0.006f) * 2) : 6);
    if (ix > SCR_W || ix < -64) continue;
    if (d == 0) canvas.fillRoundRect(ix - 4, iy - 4, 72, 72, 9, rgb(255, 210, 80));
    GAMES[idx].icon(ix, iy);
    if (d != 0) dim(ix, iy);
  }
  canvas.fillRect(0, 103, SCR_W, 32, rgb(16, 18, 34));
  txt(GAMES[sel].name, SCR_W / 2, 107, &fonts::Font4, TFT_WHITE, textdatum_t::top_center);
  canvas.fillTriangle(5, 62, 12, 56, 12, 68, rgb(255, 210, 80)); canvas.fillTriangle(SCR_W - 5, 62, SCR_W - 12, 56, SCR_W - 12, 68, rgb(255, 210, 80));
}

// ----------------------------------------------------------------------------- ecran de veille
static float svx = 60, svy = 30, svdx = 0.9f, svdy = 0.7f; static int svGame = 0;
static void drawSaver() {
  canvas.fillScreen(0);
  for (int i = 0; i < 20; i++) { int sx = (i * 61 + 7) % SCR_W, sy = (i * 37 + 11) % SCR_H; if (((millis() / 400) + i) % 5) canvas.drawPixel(sx, sy, rgb(70, 74, 100)); }
  svx += svdx; svy += svdy; bool hit = false;
  if (svx < 0) { svx = 0; svdx = -svdx; hit = true; } if (svx > SCR_W - 64) { svx = SCR_W - 64; svdx = -svdx; hit = true; }
  if (svy < 0) { svy = 0; svdy = -svdy; hit = true; } if (svy > SCR_H - 64) { svy = SCR_H - 64; svdy = -svdy; hit = true; }
  if (hit) svGame = (svGame + 1) % NGAMES;
  GAMES[svGame].icon((int)svx, (int)svy);
  canvas.pushSprite(0, 0);
}

static void toMenu() {
  running = -1; slide = 0; g_quit = false; lastAct = millis(); saver = 0;
  M5.Speaker.stop(); applyBrightness();
}

static void splash() {
  for (int i = 0; i < 30; i++) {
    canvas.fillScreen(rgb(16, 18, 34));
    int y = 20 + (i < 12 ? (12 - i) * 6 : 0);
    txt("M5", SCR_W / 2, y, &fonts::Font8, rgb(255, 210, 80), textdatum_t::top_center, 0.8f);
    txt("ARCADE", SCR_W / 2, y + 64, &fonts::Font4, TFT_WHITE, textdatum_t::top_center);
    canvas.pushSprite(0, 0);
    if (i == 12) { sfx(660, 80); sfx(880, 80, false); sfx(1320, 160, false); }
    delay(40);
  }
}

void setup() {
  auto cfg = M5.config();
  M5.begin(cfg);
  pinMode(4, OUTPUT); digitalWrite(4, HIGH);   // maintien de l'alimentation (StickC Plus2)
  M5.Display.setRotation(SCR_ROT);
  mp.begin("arcade", false);
  sel = mp.getInt("sel", 0); if (sel < 0 || sel >= NGAMES) sel = 0;
  g_bright = mp.getInt("bri", 2); if (g_bright < 0 || g_bright > 4) g_bright = 2;
  g_sound = mp.getBool("snd", true);
  g_sleepIdx = mp.getInt("slp", 1); if (g_sleepIdx < 0 || g_sleepIdx > 4) g_sleepIdx = 1;
  applyBrightness();
  M5.Speaker.setVolume(140);
  canvas.setColorDepth(16);
  canvas.createSprite(SCR_W, SCR_H);
  tilt::load();
  splash();
  if (tilt::valid()) tilt::zero();             // stabilisation unique : la position tenue au demarrage = "a plat" pour tous les jeux
  else tilt::startCalibration();               // premier demarrage : assistant d'inclinaison
  lastAct = millis();
}

void loop() {
  M5.update();
  bool anyBtn = M5.BtnA.wasPressed() || M5.BtnB.wasPressed() || M5.BtnPWR.wasPressed();
  if (tilt::calibrating()) { tilt::calibrationStep(); lastAct = millis(); return; }
  if (running >= 0) {
    if (M5.BtnPWR.pressedFor(1500) || g_quit) { sfx(440, 60); sfx(330, 90, false); toMenu(); return; }
    GAMES[running].loop();
    return;
  }
  uint32_t now = millis();
  // ----- ecran de veille (uniquement dans le menu)
  if (saver) {
    if (anyBtn) { saver = 0; applyBrightness(); lastAct = now; return; }          // le 1er appui reveille seulement
    if (saver == 1) { drawSaver(); delay(16); if (now - lastAct > SLEEP_MS[g_sleepIdx] + 60000) { saver = 2; M5.Display.setBrightness(0); } }
    else delay(40);
    return;
  }
  if (anyBtn) lastAct = now;
  if (SLEEP_MS[g_sleepIdx] && now - lastAct > SLEEP_MS[g_sleepIdx]) { saver = 1; M5.Display.setBrightness(BRI[g_bright] > 40 ? 40 : BRI[g_bright]); return; }
  if (now - batT > 3000 || batT == 0) {
    batT = now; int l = M5.Power.getBatteryLevel(); if (l >= 0) batLevel = l > 100 ? 100 : l;
    batChg = M5.Power.isCharging() == m5::Power_Class::is_charging;
  }
  if (M5.BtnB.wasPressed()) { sel = (sel + 1) % NGAMES; slide = -1; sfx(1200, 20); }
  if (M5.BtnPWR.wasPressed()) { sel = (sel + NGAMES - 1) % NGAMES; slide = 1; sfx(1000, 20); }
  if (slide != 0) { slide *= 0.7f; if (fabsf(slide) < 0.03f) slide = 0; }
  if (M5.BtnA.wasPressed()) {
    mp.putInt("sel", sel); sfx(880, 50); sfx(1320, 90, false);
    g_quit = false; GAMES[sel].begin(); running = sel;
    return;
  }
  drawMenu();
  canvas.pushSprite(0, 0);
}
