// ============================================================================
//  MUSIQUE - le buzzer joue des airs connus (domaine public).
//  B = morceau suivant, HAUT = precedent, M5 = jouer / arreter.
// ============================================================================
#include "common.h"

namespace music {

struct Tune { const char* name; int bpm; const char* seq; };
// notation : NOTE[#]OCTAVE:DUREE (en temps) ; R = silence
static const Tune TUNES[] = {
  {"VIVE LE VENT", 150,
   "E5:1 E5:1 E5:2 E5:1 E5:1 E5:2 E5:1 G5:1 C5:1.5 D5:.5 E5:4 F5:1 F5:1 F5:1.5 F5:.5 F5:1 E5:1 E5:1 E5:.5 E5:.5 E5:1 D5:1 D5:1 E5:1 D5:2 G5:2 "
   "E5:1 E5:1 E5:2 E5:1 E5:1 E5:2 E5:1 G5:1 C5:1.5 D5:.5 E5:4 F5:1 F5:1 F5:1.5 F5:.5 F5:1 E5:1 E5:1 E5:.5 E5:.5 G5:1 G5:1 F5:1 D5:1 C5:4"},
  {"ODE A LA JOIE", 132,
   "E5:1 E5:1 F5:1 G5:1 G5:1 F5:1 E5:1 D5:1 C5:1 C5:1 D5:1 E5:1 E5:1.5 D5:.5 D5:2 "
   "E5:1 E5:1 F5:1 G5:1 G5:1 F5:1 E5:1 D5:1 C5:1 C5:1 D5:1 E5:1 D5:1.5 C5:.5 C5:2 "
   "D5:1 D5:1 E5:1 C5:1 D5:1 E5:.5 F5:.5 E5:1 C5:1 D5:1 E5:.5 F5:.5 E5:1 D5:1 C5:1 D5:1 G4:2"},
  {"FRERE JACQUES", 130,
   "C5:1 D5:1 E5:1 C5:1 C5:1 D5:1 E5:1 C5:1 E5:1 F5:1 G5:2 E5:1 F5:1 G5:2 "
   "G5:.5 A5:.5 G5:.5 F5:.5 E5:1 C5:1 G5:.5 A5:.5 G5:.5 F5:.5 E5:1 C5:1 C5:1 G4:1 C5:2 C5:1 G4:1 C5:2"},
  {"AU CLAIR DE LA LUNE", 120,
   "C5:1 C5:1 C5:1 D5:1 E5:2 D5:2 C5:1 E5:1 D5:1 D5:1 C5:4 "
   "C5:1 C5:1 C5:1 D5:1 E5:2 D5:2 C5:1 E5:1 D5:1 D5:1 C5:4 "
   "D5:1 D5:1 D5:1 D5:1 A4:2 A4:2 D5:1 C5:1 B4:1 A4:1 G4:4 "
   "C5:1 C5:1 C5:1 D5:1 E5:2 D5:2 C5:1 E5:1 D5:1 D5:1 C5:4"},
  {"JOYEUX ANNIVERSAIRE", 120,
   "G4:.75 G4:.25 A4:1 G4:1 C5:1 B4:2 G4:.75 G4:.25 A4:1 G4:1 D5:1 C5:2 "
   "G4:.75 G4:.25 G5:1 E5:1 C5:1 B4:1 A4:1 F5:.75 F5:.25 E5:1 C5:1 D5:1 C5:3"},
  {"AH VOUS DIRAI-JE MAMAN", 135,
   "C5:1 C5:1 G5:1 G5:1 A5:1 A5:1 G5:2 F5:1 F5:1 E5:1 E5:1 D5:1 D5:1 C5:2 "
   "G5:1 G5:1 F5:1 F5:1 E5:1 E5:1 D5:2 G5:1 G5:1 F5:1 F5:1 E5:1 E5:1 D5:2 "
   "C5:1 C5:1 G5:1 G5:1 A5:1 A5:1 G5:2 F5:1 F5:1 E5:1 E5:1 D5:1 D5:1 C5:2"},
  {"POUR ELISE", 118,
   "E5:.5 D#5:.5 E5:.5 D#5:.5 E5:.5 B4:.5 D5:.5 C5:.5 A4:1.5 R:.5 C4:.5 E4:.5 A4:.5 B4:1.5 R:.5 E4:.5 G#4:.5 B4:.5 C5:1.5 R:.5 "
   "E4:.5 E5:.5 D#5:.5 E5:.5 D#5:.5 E5:.5 B4:.5 D5:.5 C5:.5 A4:1.5 R:.5 C4:.5 E4:.5 A4:.5 B4:1.5 R:.5 E4:.5 C5:.5 B4:.5 A4:3"},
  {"KOROBEINIKI", 140,
   "E5:1 B4:.5 C5:.5 D5:1 C5:.5 B4:.5 A4:1 A4:.5 C5:.5 E5:1 D5:.5 C5:.5 B4:1.5 C5:.5 D5:1 E5:1 C5:1 A4:1 A4:2 "
   "D5:1.5 F5:.5 A5:1 G5:.5 F5:.5 E5:1.5 C5:.5 E5:1 D5:.5 C5:.5 B4:1 B4:.5 C5:.5 D5:1 E5:1 C5:1 A4:1 A4:2"},
  {"MARCHE TURQUE", 128,
   "B4:.25 A4:.25 G#4:.25 A4:.25 C5:1 D5:.25 C5:.25 B4:.25 C5:.25 E5:1 F5:.25 E5:.25 D#5:.25 E5:.25 B5:.25 A5:.25 G#5:.25 A5:.25 B5:.25 A5:.25 G#5:.25 A5:.25 C6:1 A5:.5 C6:.5 B5:.5 A5:.5 G#5:.5 A5:.5 E5:2"},
};
static const int NT = sizeof(TUNES) / sizeof(TUNES[0]);

struct Note { float freq; int start, dur; int midi; };         // en millisecondes
static Note notes[160]; static int nNotes = 0, totalMs = 0, minMidi = 60, maxMidi = 72;
static int sel = 0; static bool playing = false; static uint32_t t0 = 0, lastNow = 0; static int curNote = -1;
static int animT = 0;
struct Spark { float x, y, vx, vy; int t; uint16_t c; }; static Spark sp[30];

static int midiOf(const char* s, int &adv) {
  static const int base[7] = {9, 11, 0, 2, 4, 5, 7};      // A B C D E F G
  int i = 0, n = base[s[i++] - 'A'];
  if (s[i] == '#') { n++; i++; }
  int oct = s[i++] - '0'; adv = i;
  return 12 * (oct + 1) + n;
}
static void parse(int k) {
  const Tune &t = TUNES[k]; float beat = 60000.f / t.bpm; int ms = 0;
  nNotes = 0; minMidi = 200; maxMidi = 0;
  const char* p = t.seq;
  while (*p && nNotes < 160) {
    while (*p == ' ') p++;
    if (!*p) break;
    int midi = -1, adv = 0;
    if (*p == 'R') { p++; } else { midi = midiOf(p, adv); p += adv; }
    p++;                                                    // ':'
    float d = atof(p); while (*p && *p != ' ') p++;
    int dur = (int)(d * beat);
    if (midi >= 0) { notes[nNotes++] = {440.f * powf(2.f, (midi - 69) / 12.f), ms, dur, midi}; if (midi < minMidi) minMidi = midi; if (midi > maxMidi) maxMidi = midi; }
    ms += dur;
  }
  totalMs = ms; if (maxMidi - minMidi < 8) maxMidi = minMidi + 8;
}
void begin() {
  Preferences pr; pr.begin("music", false); sel = pr.getInt("sel", 0) % NT;
  parse(sel); playing = false; curNote = -1; for (auto &s : sp) s.t = 0;
}
static void startPlay() { playing = true; t0 = millis(); curNote = -1; }
static void stopPlay() { playing = false; M5.Speaker.stop(); }

static uint16_t hueCol(int midi) {
  static const uint16_t pal[12] = {rgb(255, 80, 90), rgb(255, 130, 70), rgb(255, 190, 60), rgb(240, 230, 70), rgb(160, 230, 80), rgb(70, 220, 130), rgb(60, 220, 210), rgb(70, 170, 255), rgb(110, 120, 255), rgb(170, 110, 255), rgb(230, 100, 240), rgb(255, 100, 180)};
  return pal[midi % 12];
}
static int yOf(int midi) { return 112 - (midi - minMidi) * 84 / (maxMidi - minMidi); }

static void step() {
  animT++;
  for (auto &s : sp) if (s.t > 0) { s.t--; s.x += s.vx; s.y += s.vy; s.vy += 0.08f; }
  if (!playing) return;
  int now = (int)(millis() - t0);
  if (now >= totalMs + 300) { stopPlay(); return; }
  for (int i = 0; i < nNotes; i++) {
    if (now >= notes[i].start && now < notes[i].start + notes[i].dur) {
      if (i != curNote) {
        curNote = i;
        sfx((int)notes[i].freq, notes[i].dur * 9 / 10 > 30 ? notes[i].dur * 9 / 10 : 30, true);
        for (int k = 0; k < 6; k++) for (auto &s : sp) if (s.t <= 0) { s = {80, (float)yOf(notes[i].midi) + 4, rnd(0, 20) / 10.f - 0.6f, -rnd(5, 20) / 10.f, 24, hueCol(notes[i].midi)}; break; }
      }
      break;
    }
  }
}

static void render() {
  canvas.fillScreen(rgb(10, 8, 26));
  int now = playing ? (int)(millis() - t0) : 0;
  // lignes de portee
  for (int i = 0; i < 5; i++) canvas.drawFastHLine(0, 30 + i * 18, SCR_W, rgb(24, 22, 52));
  const int HX = 80; const float PXMS = 0.09f;
  // notes : barres qui defilent vers la gauche, tete de lecture a HX
  for (int i = 0; i < nNotes; i++) {
    float x0 = HX + (notes[i].start - now) * PXMS, w = notes[i].dur * PXMS - 2;
    if (x0 > SCR_W || x0 + w < 0) continue;
    int y = yOf(notes[i].midi); uint16_t c = hueCol(notes[i].midi);
    bool active = playing && now >= notes[i].start && now < notes[i].start + notes[i].dur;
    bool past = playing && now >= notes[i].start + notes[i].dur;
    uint16_t cc = past ? mixc(c, rgb(10, 8, 26), 170) : c;
    if (w < 3) w = 3;
    if (active) canvas.fillRoundRect((int)x0 - 2, y - 2, (int)w + 4, 11, 4, TFT_WHITE);
    canvas.fillRoundRect((int)x0, y, (int)w, 7, 3, cc);
    if (!past) canvas.drawFastHLine((int)x0 + 2, y + 1, (int)w - 4, mixc(cc, 0xFFFF, 110));
  }
  canvas.drawFastVLine(HX, 18, 100, rgb(255, 255, 255)); canvas.fillTriangle(HX - 5, 14, HX + 5, 14, HX, 22, rgb(255, 255, 255));
  for (auto &s : sp) if (s.t > 0) canvas.fillRect((int)s.x, (int)s.y, 2, 2, s.c);
  // titre
  canvas.fillRect(0, 0, SCR_W, 13, rgb(18, 14, 44));
  txt(TUNES[sel].name, SCR_W / 2, 0, &fonts::Font2, TFT_WHITE, textdatum_t::top_center);
  canvas.fillTriangle(5, 6, 11, 2, 11, 10, rgb(255, 210, 80)); canvas.fillTriangle(SCR_W - 5, 6, SCR_W - 11, 2, SCR_W - 11, 10, rgb(255, 210, 80));
  // barre de progression + bouton lecture
  canvas.fillRect(0, 124, SCR_W, 11, rgb(18, 14, 44));
  int prog = playing ? (int)(SCR_W * clampf(now / (float)totalMs, 0, 1)) : 0;
  canvas.fillRect(0, 130, SCR_W, 3, rgb(40, 36, 80)); canvas.fillRect(0, 130, prog, 3, rgb(255, 210, 80));
  if (playing) { canvas.fillRect(SCR_W / 2 - 6, 125, 4, 6, TFT_WHITE); canvas.fillRect(SCR_W / 2 + 2, 125, 4, 6, TFT_WHITE); }
  else canvas.fillTriangle(SCR_W / 2 - 4, 125, SCR_W / 2 - 4, 131, SCR_W / 2 + 4, 128, rgb(120, 255, 160));
  // petit equaliseur
  if (playing && curNote >= 0) for (int i = 0; i < 6; i++) { int h = 3 + (int)((sinf(animT * 0.5f + i * 1.3f) + 1.0f) * 4); canvas.fillRect(8 + i * 5, 130 - h, 3, h, hueCol(notes[curNote].midi)); }
}

void loop() {
  bool a = M5.BtnA.wasPressed(), p = M5.BtnPWR.wasPressed(), b = M5.BtnB.wasPressed();
  if (b || p) {
    stopPlay(); sel = (sel + (b ? 1 : NT - 1)) % NT; parse(sel); sfx(b ? 1200 : 1000, 20);
    Preferences pr; pr.begin("music", false); pr.putInt("sel", sel);
  } else if (a) { if (playing) stopPlay(); else startPlay(); }
  step();
  render();
  canvas.pushSprite(0, 0);
  delay(8);
}

void icon(int x, int y) {
  canvas.fillRoundRect(x, y, 64, 64, 6, rgb(10, 8, 26));
  static const int ys[7] = {40, 30, 36, 22, 28, 16, 24}; static const int ws[7] = {8, 6, 10, 6, 8, 10, 7};
  int xx = x + 4;
  for (int i = 0; i < 6; i++) { canvas.fillRoundRect(xx, y + ys[i], ws[i], 7, 3, hueCol(i * 2)); xx += ws[i] + 2; }
  canvas.fillCircle(x + 20, y + 52, 4, rgb(255, 255, 255)); canvas.fillRect(x + 23, y + 38, 2, 15, TFT_WHITE);
  canvas.fillCircle(x + 40, y + 54, 4, rgb(255, 255, 255)); canvas.fillRect(x + 43, y + 40, 2, 15, TFT_WHITE); canvas.fillRect(x + 23, y + 38, 22, 3, TFT_WHITE);
}

}  // namespace music
