// ============================================================================
//  COURSE - choisis ta voiture (B / HAUT pour changer, M5 pour valider), puis ta couleur.
//  Penche le M5 pour piloter. M5 maintenu = nitro. HAUT = pause.
// ============================================================================
#include "common.h"

namespace race {

static const uint32_t STEP_US = 20000;
static const int ROAD_L = 58, ROAD_R = 182, PY = 102;
static const int LANE[3] = {79, 120, 161};
enum State { SEL_CAR, SEL_COLOR, PLAY, PAUSED, OVER };
static State state = SEL_CAR;
static Preferences pr;
static uint32_t last = 0, acc = 0;

struct CarDef { const char* name; int speedStars, handStars; };
static const CarDef CARS[3] = {{"COUPE GT", 3, 3}, {"SUPERCAR", 5, 2}, {"ROADSTER", 2, 5}};
static const uint16_t COLS[7] = {rgb(222, 28, 40), rgb(250, 125, 20), rgb(250, 205, 20), rgb(40, 185, 75), rgb(35, 100, 235), rgb(238, 238, 244), rgb(36, 36, 44)};
static const char* CNAME[7] = {"ROUGE", "ORANGE", "JAUNE", "VERT", "BLEU", "BLANC", "NOIR"};
static int carSel = 0, colSel = 0;

struct Veh { float x, y, v; uint8_t kind, col; bool on, passed; };
static Veh veh[8];
struct Deco { float x, y; uint8_t t; }; static Deco deco[14];
struct Pop { float x, y; int t; char s[12]; uint16_t col; }; static Pop pops[3];

static float px = 120, pv = 0, spd = 2.5f, nitro = 1.0f, dist = 0, off = 0, lightF = 1;
static int lives = 3, invul = 0, endT = 0, animT = 0, steps = 0, spawnT = 0, shake = 0;
static uint32_t score = 0, best = 0, bonus = 0;
static bool boosting = false;

static inline uint16_t Lc(int r, int g, int b) { return rgb((int)(r * lightF), (int)(g * lightF), (int)(b * lightF)); }
static void pop(float x, float y, const char* s, uint16_t col) { for (auto &p : pops) if (p.t <= 0) { p.x = x; p.y = y; p.t = 36; p.col = col; strncpy(p.s, s, 11); p.s[11] = 0; return; } }

// --------------------------------------------------------------------------- voitures (vue de dessus, nez en haut)
// kind : 0 coupe GT, 1 supercar, 2 roadster, 3 berline, 4 camion
static void drawCar(int cx, int cy, int kind, uint16_t col, int s, bool shadow) {
  auto R = [&](int x, int y, int w, int h, uint16_t c) { canvas.fillRect(cx + x * s, cy + y * s, w * s, h * s, c); };
  auto RR = [&](int x, int y, int w, int h, int r, uint16_t c) { canvas.fillRoundRect(cx + x * s, cy + y * s, w * s, h * s, r * s, c); };
  uint16_t dark = mixc(col, 0, 105), light = mixc(col, 0xFFFF, 95);
  uint16_t glass = rgb(30, 44, 70), glassHi = rgb(120, 160, 200), tire = rgb(18, 18, 22), lamp = rgb(255, 245, 170), tail = rgb(235, 30, 30);
  if (shadow) canvas.fillEllipse(cx + 2 * s, cy + 2 * s, (kind == 4 ? 10 : 9) * s, (kind == 4 ? 21 : 15) * s, rgb(20, 24, 22));
  if (kind == 0) {            // coupe GT
    R(-9, -10, 4, 7, tire); R(5, -10, 4, 7, tire); R(-9, 5, 4, 8, tire); R(5, 5, 4, 8, tire);
    RR(-7, -14, 14, 28, 5, col);
    R(-7, -7, 2, 19, light); R(5, -7, 2, 19, dark);
    R(-1, -13, 2, 8, mixc(col, 0xFFFF, 60));
    RR(-5, -5, 10, 5, 2, glass); R(-4, -4, 8, 1, glassHi);
    RR(-5, 0, 10, 6, 1, dark);
    RR(-5, 6, 10, 4, 2, glass);
    R(-6, -14, 3, 2, lamp); R(3, -14, 3, 2, lamp); R(-6, 12, 3, 2, tail); R(3, 12, 3, 2, tail);
    R(-9, -4, 2, 3, col); R(7, -4, 2, 3, col);
  } else if (kind == 1) {     // supercar
    R(-10, -12, 4, 8, tire); R(6, -12, 4, 8, tire); R(-10, 3, 4, 9, tire); R(6, 3, 4, 9, tire);
    canvas.fillTriangle(cx - 6 * s, cy - 6 * s, cx + 6 * s, cy - 6 * s, cx, cy - 17 * s, col);
    RR(-8, -8, 16, 22, 4, col);
    R(-8, -2, 3, 6, dark); R(5, -2, 3, 6, dark);
    R(-1, -16, 2, 11, rgb(245, 245, 250));
    RR(-4, -5, 8, 8, 3, glass); R(-3, -4, 6, 1, glassHi);
    R(-3, 4, 6, 7, dark); R(-2, 5, 4, 1, rgb(10, 10, 12)); R(-2, 7, 4, 1, rgb(10, 10, 12)); R(-2, 9, 4, 1, rgb(10, 10, 12));
    R(-10, 12, 20, 3, dark); R(-10, 11, 2, 5, rgb(12, 12, 14)); R(8, 11, 2, 5, rgb(12, 12, 14));
    R(-5, -11, 3, 1, lamp); R(2, -11, 3, 1, lamp); R(-6, 15, 3, 1, tail); R(3, 15, 3, 1, tail);
  } else if (kind == 2) {     // roadster decapotable
    R(-9, -10, 4, 7, tire); R(5, -10, 4, 7, tire); R(-9, 5, 4, 8, tire); R(5, 5, 4, 8, tire);
    RR(-7, -14, 14, 28, 6, col);
    R(-7, -8, 2, 20, light); R(5, -8, 2, 20, dark);
    RR(-5, -4, 10, 12, 3, rgb(26, 26, 32));
    RR(-4, -1, 3, 5, 1, rgb(58, 58, 70)); RR(1, -1, 3, 5, 1, rgb(58, 58, 70));
    R(-6, -5, 12, 2, glass); R(-5, -5, 10, 1, glassHi);
    canvas.fillCircle(cx - 2 * s, cy + 2 * s, 2 * s, rgb(240, 240, 245));
    R(-4, 7, 2, 2, dark); R(2, 7, 2, 2, dark);
    R(-6, -14, 3, 2, lamp); R(3, -14, 3, 2, lamp); R(-5, 13, 10, 1, tail);
  } else if (kind == 3) {     // berline
    R(-9, -9, 3, 6, tire); R(6, -9, 3, 6, tire); R(-9, 5, 3, 7, tire); R(6, 5, 3, 7, tire);
    RR(-7, -13, 14, 26, 3, col);
    R(-7, -6, 1, 18, light);
    RR(-6, -5, 12, 5, 1, glass); R(-5, -4, 10, 1, glassHi);
    RR(-6, 0, 12, 7, 1, dark);
    RR(-6, 7, 12, 4, 1, glass);
    R(-6, -13, 3, 2, lamp); R(3, -13, 3, 2, lamp); R(-6, 11, 3, 2, tail); R(3, 11, 3, 2, tail);
  } else {                    // camion
    R(-9, -15, 3, 6, tire); R(6, -15, 3, 6, tire); R(-9, 8, 3, 6, tire); R(6, 8, 3, 6, tire); R(-9, 14, 3, 5, tire); R(6, 14, 3, 5, tire);
    RR(-7, -19, 14, 12, 3, col);
    RR(-6, -16, 12, 4, 1, glass); R(-5, -15, 10, 1, glassHi);
    RR(-8, -6, 16, 25, 2, rgb(206, 210, 216));
    for (int i = 0; i < 5; i++) R(-8, -2 + i * 5, 16, 1, rgb(160, 166, 174));
    R(-7, -19, 3, 2, lamp); R(4, -19, 3, 2, lamp); R(-7, 18, 3, 1, tail); R(4, 18, 3, 1, tail);
  }
}
static int hhOf(int kind) { return kind == 4 ? 19 : (kind == 1 ? 16 : 14); }
static int hwOf(int kind) { return kind == 4 ? 8 : 7; }

// --------------------------------------------------------------------------- jeu
static void reset() {
  px = 120; pv = 0; spd = 2.5f; nitro = 1.0f; dist = 0; off = 0; lives = 3; invul = 0; endT = 0; steps = 0; spawnT = 40; score = 0; bonus = 0; shake = 0;
  for (auto &v : veh) v.on = false;
  for (auto &p : pops) p.t = 0;
  for (int i = 0; i < 14; i++) deco[i] = {(float)((i & 1) ? rnd(196, 232) : rnd(8, 44)), (float)(i * 10), (uint8_t)rnd(0, 2)};
}
void begin() {
  pr.begin("race", false); best = pr.getInt("best", 0); carSel = pr.getInt("car", 0) % 3; colSel = pr.getInt("col", 0) % 7;
  reset(); state = SEL_CAR; last = 0; acc = 0;
}
static void gameOver() {
  state = OVER; endT = 0;
  if (score > best) { best = score; pr.putInt("best", best); }
  sfx(260, 120); sfx(110, 320, false);
}
static void spawnRow() {
  int mask = 0, n = (rnd(0, 99) < 30) ? 2 : 1;
  while (__builtin_popcount(mask) < n) mask |= 1 << rnd(0, 2);
  for (int l = 0; l < 3; l++) if (mask & (1 << l)) {
    for (auto &v : veh) if (!v.on) {
      uint8_t k = rnd(0, 99) < 14 ? 4 : (uint8_t)rnd(0, 3);
      v = {(float)LANE[l] + (int)rnd(0, 6) - 3, -24.f, 1.0f + rnd(0, 9) * 0.09f, k, (uint8_t)rnd(0, 6), true, false};
      break;
    }
  }
}

static void step() {
  animT++;
  for (auto &p : pops) if (p.t > 0) { p.t--; p.y -= 0.5f; }
  if (shake > 0) shake--;
  if (state == SEL_CAR || state == SEL_COLOR || state == PAUSED) return;
  if (state == OVER) { endT++; spd *= 0.97f; off += spd; for (auto &v : veh) if (v.on) { v.y += spd - v.v; } return; }
  tilt::update();
  const CarDef &cd = CARS[carSel];
  float steerM = 0.7f + 0.12f * cd.handStars, topM = 0.95f + 0.06f * cd.speedStars;
  float t = tilt::x(); if (fabsf(t) < 0.06f) t = 0; else t = t > 0 ? t - 0.06f : t + 0.06f;
  pv += (t * 4.6f * steerM - pv) * 0.25f;
  px += pv;
  if (px < ROAD_L + 8) { px = ROAD_L + 8; pv = 0; spd *= 0.985f; }
  if (px > ROAD_R - 8) { px = ROAD_R - 8; pv = 0; spd *= 0.985f; }
  boosting = M5.BtnA.isPressed() && nitro > 0.02f;
  if (boosting) nitro -= 0.006f; else if (nitro < 1.0f) nitro += 0.0015f;
  steps++;
  float vmax = (2.6f + steps * 0.0007f); if (vmax > 4.3f) vmax = 4.3f;
  vmax *= topM / 1.1f;
  float target = vmax + (boosting ? 1.5f : 0.0f);
  spd += (target - spd) * 0.04f;
  dist += spd; off += spd;
  score = (uint32_t)(dist / 10) + bonus;
  lightF = 0.72f + 0.28f * cosf(dist * 0.0004f);
  if (invul > 0) invul--;
  if (--spawnT <= 0) { spawnRow(); int T = (int)(44 - spd * 4.2f); spawnT = T < 18 ? 18 : T; }
  for (auto &d : deco) { d.y += spd; if (d.y > SCR_H + 14) { d.y -= SCR_H + 40; d.x = (rnd(0, 1)) ? rnd(196, 232) : rnd(8, 44); d.t = rnd(0, 2); } }
  for (auto &v : veh) if (v.on) {
    v.y += spd - v.v;
    if (v.y > SCR_H + 30) { v.on = false; continue; }
    int hh = hhOf(v.kind), hw = hwOf(v.kind);
    float dx = fabsf(v.x - px), dy = fabsf(v.y - PY);
    if (!invul && dx < hw + 6 && dy < hh + 11) {
      v.on = false; if (--lives <= 0) { gameOver(); return; }
      invul = 90; shake = 14; spd *= 0.55f; pop(px, PY - 22, "CRASH", rgb(255, 90, 60)); sfx(150, 100); sfx(90, 180, false);
      continue;
    }
    if (!v.passed && v.y > PY + hh + 4) {
      v.passed = true;
      if (dx < 21) { bonus += 5; pop(px, PY - 22, "FROLE +5", rgb(255, 230, 90)); sfx(1500, 30); sfx(1900, 40, false); }
    }
  }
}

// --------------------------------------------------------------------------- dessin
static void drawTree(int x, int y, int t) {
  int r = 6 + t * 2;
  canvas.fillCircle(x + 3, y + 3, r, Lc(25, 70, 32));
  canvas.fillCircle(x, y, r, Lc(34, 105, 44)); canvas.fillCircle(x - 2, y - 2, r - 3, Lc(48, 135, 58)); canvas.fillCircle(x - 3, y - 3, r / 3, Lc(90, 175, 90));
}
static void drawRoad() {
  int o = (int)off;
  for (int y = 0; y < SCR_H; y++) {
    bool band = (((y - o) % 32 + 32) % 32) < 16;
    uint16_t g = band ? Lc(50, 128, 56) : Lc(44, 117, 50);
    canvas.drawFastHLine(0, y, ROAD_L - 8, g); canvas.drawFastHLine(ROAD_R + 8, y, SCR_W - ROAD_R - 8, g);
  }
  canvas.fillRect(ROAD_L, 0, ROAD_R - ROAD_L, SCR_H, Lc(70, 72, 82));
  for (int y = 0; y < SCR_H; y++) {                      // bordures rouge / blanc
    bool rb = (((y - o) % 16 + 16) % 16) < 8;
    uint16_t c = rb ? Lc(225, 40, 40) : Lc(235, 235, 235);
    canvas.drawFastHLine(ROAD_L - 8, y, 6, c); canvas.drawFastHLine(ROAD_R + 2, y, 6, c);
    canvas.drawFastHLine(ROAD_L - 2, y, 2, Lc(235, 235, 235)); canvas.drawFastHLine(ROAD_R, y, 2, Lc(235, 235, 235));
  }
  for (int l = 0; l < 2; l++) { int lx = (LANE[l] + LANE[l + 1]) / 2; for (int y = -32; y < SCR_H; y += 28) { int yy = y + (o % 28); canvas.fillRect(lx - 1, yy, 2, 14, Lc(220, 220, 225)); } }
  // taches d'huile / usure de l'asphalte (fixes par rapport a la route)
  for (int i = 0; i < 6; i++) { int yy = ((i * 53) + o) % SCR_H; canvas.drawFastHLine(ROAD_L + 6 + (i * 37) % 100, yy, 7 + i, Lc(62, 64, 74)); }
}
static void render() {
  canvas.fillScreen(0);
  if (state == SEL_CAR || state == SEL_COLOR) {
    for (int y = 0; y < SCR_H; y += 3) canvas.fillRect(0, y, SCR_W, 3, mixc(rgb(8, 10, 22), rgb(38, 42, 70), y * 256 / SCR_H));
    canvas.fillEllipse(120, 100, 80, 15, rgb(52, 56, 84)); canvas.fillEllipse(120, 100, 64, 10, rgb(70, 76, 110));
    drawCar(120, 72, carSel, COLS[colSel], 2, false);
    canvas.fillTriangle(14, 72, 28, 60, 28, 84, rgb(255, 210, 80)); canvas.fillTriangle(226, 72, 212, 60, 212, 84, rgb(255, 210, 80));
    if (state == SEL_CAR) {
      txt(CARS[carSel].name, SCR_W / 2, 4, &fonts::Font4, TFT_WHITE, textdatum_t::top_center);
      txt("VITESSE", 6, 112, &fonts::Font0, rgb(150, 160, 210)); txt("MANIAB.", 6, 124, &fonts::Font0, rgb(150, 160, 210));
      for (int i = 0; i < 5; i++) { canvas.fillRect(56 + i * 8, 111, 6, 8, i < CARS[carSel].speedStars ? rgb(255, 210, 80) : rgb(60, 64, 90)); canvas.fillRect(56 + i * 8, 123, 6, 8, i < CARS[carSel].handStars ? rgb(90, 220, 255) : rgb(60, 64, 90)); }
    } else {
      txt(CNAME[colSel], SCR_W / 2, 4, &fonts::Font4, TFT_WHITE, textdatum_t::top_center);
      for (int i = 0; i < 7; i++) { int cx = 120 + (i - 3) * 24; canvas.fillCircle(cx, 121, i == colSel ? 7 : 5, COLS[i]); if (i == colSel) canvas.drawCircle(cx, 121, 9, TFT_WHITE); }
    }
    return;
  }
  drawRoad();
  for (auto &d : deco) drawTree((int)d.x, (int)d.y, d.t);
  // phares la nuit
  if (lightF < 0.66f && state != OVER) {
    int pxi = (int)px;
    canvas.fillTriangle(pxi - 5, PY - 14, pxi - 13, PY - 60, pxi - 1, PY - 60, mixc(Lc(70, 72, 82), rgb(255, 250, 190), 70));
    canvas.fillTriangle(pxi + 5, PY - 14, pxi + 1, PY - 60, pxi + 13, PY - 60, mixc(Lc(70, 72, 82), rgb(255, 250, 190), 70));
  }
  // vehicules (du plus haut au plus bas)
  for (auto &v : veh) if (v.on) drawCar((int)v.x, (int)v.y, v.kind, COLS[v.col], 1, true);
  if (state != OVER || (animT & 8)) {
    if (invul == 0 || (animT & 4)) {
      int sx = (int)px + ((shake > 0) ? (int)rnd(0, 2) - 1 : 0);
      if (boosting) { int f = 4 + (animT & 3) * 3; canvas.fillTriangle(sx - 4, PY + 14, sx + 4, PY + 14, sx, PY + 15 + f, rgb(80, 170, 255)); canvas.fillTriangle(sx - 2, PY + 14, sx + 2, PY + 14, sx, PY + 14 + f / 2, rgb(255, 255, 255)); }
      drawCar(sx, PY, carSel, COLS[colSel], 1, true);
    }
  }
  if (boosting) for (int i = 0; i < 6; i++) { int lx = ROAD_L + 10 + (i * 41 + animT * 7) % (ROAD_R - ROAD_L - 20), ly = (i * 29 + animT * 11) % SCR_H; canvas.drawFastVLine(lx, ly, 10, rgb(200, 210, 240)); }
  for (auto &p : pops) if (p.t > 0) txtO(p.s, (int)p.x, (int)p.y, &fonts::Font2, p.col, rgb(0, 0, 0), textdatum_t::top_center);
  char b[24];
  snprintf(b, sizeof b, "%lu", (unsigned long)score); txtO(b, 5, 2, &fonts::Font4, TFT_WHITE, rgb(10, 10, 20));
  for (int i = 0; i < lives; i++) { int hx = SCR_W - 10 - i * 12; canvas.fillTriangle(hx - 4, 6, hx + 4, 6, hx, 13, rgb(235, 50, 60)); canvas.fillCircle(hx - 2, 5, 2, rgb(235, 50, 60)); canvas.fillCircle(hx + 2, 5, 2, rgb(235, 50, 60)); }
  snprintf(b, sizeof b, "%d", (int)(spd * 45)); txtO(b, SCR_W - 6, 108, &fonts::Font4, TFT_WHITE, rgb(10, 10, 20), textdatum_t::top_right); txtO("km/h", SCR_W - 6, 126, &fonts::Font0, TFT_WHITE, rgb(10, 10, 20), textdatum_t::top_right);
  canvas.drawRect(5, 122, 52, 8, rgb(230, 230, 240)); canvas.fillRect(6, 123, (int)(50 * nitro), 6, boosting ? rgb(80, 180, 255) : rgb(60, 130, 230));
  if (state == PAUSED) { canvas.fillRoundRect(80, 50, 80, 28, 5, rgb(10, 12, 28)); txt("PAUSE", SCR_W / 2, 54, &fonts::Font4, TFT_WHITE, textdatum_t::top_center); }
  if (state == OVER) {
    canvas.fillRoundRect(36, 28, 168, 62, 6, rgb(10, 12, 28)); canvas.drawRoundRect(36, 28, 168, 62, 6, rgb(235, 60, 70));
    txt("ACCIDENT !", SCR_W / 2, 32, &fonts::Font4, rgb(235, 60, 70), textdatum_t::top_center);
    snprintf(b, sizeof b, "%lu   record %lu", (unsigned long)score, (unsigned long)best); txt(b, SCR_W / 2, 60, &fonts::Font2, TFT_WHITE, textdatum_t::top_center);
    if (endT > 40) txt("M5 rejouer    B garage", SCR_W / 2, 76, &fonts::Font0, rgb(150, 200, 255), textdatum_t::top_center);
  }
}

void loop() {
  uint32_t now = micros();
  if (last == 0) last = now;
  acc += now - last; last = now; if (acc > 100000) acc = 100000;
  bool a = M5.BtnA.wasPressed(), p = M5.BtnPWR.wasPressed(), b = M5.BtnB.wasPressed();
  switch (state) {
    case SEL_CAR:
      if (b) { carSel = (carSel + 1) % 3; sfx(1200, 20); } else if (p) { carSel = (carSel + 2) % 3; sfx(1000, 20); }
      else if (a) { state = SEL_COLOR; sfx(880, 40); }
      break;
    case SEL_COLOR:
      if (b) { colSel = (colSel + 1) % 7; sfx(1200, 20); } else if (p) { colSel = (colSel + 6) % 7; sfx(1000, 20); }
      else if (a) { pr.putInt("car", carSel); pr.putInt("col", colSel); reset(); state = PLAY; sfx(660, 40); sfx(990, 60, false); }
      break;
    case PLAY: if (p) { state = PAUSED; sfx(440, 50); } break;
    case PAUSED: if (p || a) { state = PLAY; sfx(660, 50); } break;
    case OVER:
      if (endT > 40) { if (a) { reset(); state = PLAY; sfx(660, 40); } else if (b) { reset(); state = SEL_CAR; sfx(880, 40); } }
      break;
  }
  while (acc >= STEP_US) { step(); acc -= STEP_US; }
  render();
  canvas.pushSprite(0, 0);
}

void icon(int x, int y) {
  canvas.fillRoundRect(x, y, 64, 64, 6, Lc(70, 72, 82));
  canvas.fillRect(x, y, 6, 64, rgb(50, 128, 56)); canvas.fillRect(x + 58, y, 6, 64, rgb(50, 128, 56));
  for (int i = 0; i < 4; i++) { canvas.fillRect(x + 6, y + 4 + i * 16, 2, 8, rgb(225, 40, 40)); canvas.fillRect(x + 56, y + 4 + i * 16, 2, 8, rgb(225, 40, 40)); canvas.fillRect(x + 31, y + 2 + i * 16, 2, 8, rgb(220, 220, 225)); }
  lightF = 1;
  drawCar(x + 46, y + 22, 3, rgb(240, 240, 245), 1, false);
  drawCar(x + 22, y + 40, 1, rgb(222, 28, 40), 1, true);
}

}  // namespace race
